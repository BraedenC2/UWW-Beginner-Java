import java.util.Scanner;

public class ComputingSeries {
    static int userIn, step = 0;

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        userIn = scanner.nextInt();
        while (userIn < 1) {
            System.out.println("Enter a positive integer: ");
            userIn = scanner.nextInt();
        }

        while (userIn != 1) {

            if (userIn % 2 == 0){

                userIn = userIn / 2;
                System.out.print(userIn + " ");

            } else {

                userIn = userIn * 3 + 1;
                System.out.print(userIn + " ");

            }
            step++;
        }

        System.out.print("\nIt took " + step + " steps to reach 1. ");

    }
}
