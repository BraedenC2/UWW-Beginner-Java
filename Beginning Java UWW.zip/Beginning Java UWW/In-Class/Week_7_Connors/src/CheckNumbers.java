import java.util.Scanner;

public class CheckNumbers {
    static int userIn, sum, oddNum, evenNum;

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an Integer, enter 0 to quit: ");
        userIn = scanner.nextInt();

        while (userIn != 0) {

            if (userIn % 2 == 0){

                evenNum++;
                System.out.println(userIn + " is an even number");

            } else {

                oddNum++;
                System.out.println(userIn + " is an odd number");

            }

            sum += userIn;
            System.out.print("Enter an Integer, enter 0 to quit: ");
            userIn = scanner.nextInt();

        }

        System.out.println("Even numbers = " + evenNum);
        System.out.println("Odd numbers = " + oddNum);
        System.out.println("Sum = " + sum);


    }
}
