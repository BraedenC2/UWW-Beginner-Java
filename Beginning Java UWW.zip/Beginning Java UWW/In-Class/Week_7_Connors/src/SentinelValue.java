import java.util.Scanner;

public class SentinelValue {

    static int userIn, sum;

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an Integer, enter 0 to quit: ");
        userIn = scanner.nextInt();

        while (userIn != 0) {

            sum += userIn;
            System.out.print("Enter an Integer, enter 0 to quit: ");
            userIn = scanner.nextInt();

        }

        System.out.println("Sum = " + sum);

    }
}
