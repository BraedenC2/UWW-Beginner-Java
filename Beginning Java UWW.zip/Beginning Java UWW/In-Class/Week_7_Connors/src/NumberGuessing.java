import java.util.Scanner;

public class NumberGuessing {

    public static void main(String[] args){

        int x = (int) (Math.random() * (10 + 1) + 0), guess, count = 1;

        Scanner scanner = new Scanner(System.in);

        do {

            System.out.println("Enter your guess: ");
            guess = scanner.nextInt();
            if (guess == x){

                System.out.println("Yes, the number is " + x);

            } else if (guess < x){

                System.out.println("Your guess is too low");
                count++;

            } else {

                System.out.println("Your guess is too high !!");
                count++;

            }

        } while (guess != x);

        System.out.println("Congrats! You got it in " + count + " guesses");
    }
}
