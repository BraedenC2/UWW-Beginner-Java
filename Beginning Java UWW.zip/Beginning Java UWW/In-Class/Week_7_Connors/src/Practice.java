public class Practice {

    public static void main(String[] args){

        for(int i = 1; i <= 3; i++) {

            char x = (char) (int) ((Math.random() * (90 - 65 + 1) + 65));
            System.out.print(x);
        }

        for (int i = 1; i <= 4; i++){

            int x = (int)(Math.random()*10);
            System.out.println(x);

        }

    }
}
