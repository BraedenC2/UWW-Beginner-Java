import java.util.Scanner;

public class FindLargest {
    static int x = 1, userIn;

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        while (x <= 5){

            System.out.println("Enter number " + x + " : ");
            userIn = scanner.nextInt();
            x++;

        }

        System.out.println("\nThe largest is " + "");








    }

}
