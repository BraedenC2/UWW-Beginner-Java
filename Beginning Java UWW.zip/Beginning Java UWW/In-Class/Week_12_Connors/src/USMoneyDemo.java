public class USMoneyDemo {

    public static void main(String[] args){

        // Create a USMoney object
        USMoney s1 = new USMoney(12, 245);
        USMoney s2 = new USMoney(15, -23);
        USMoney s3 = new USMoney(12, 5);
        System.out.println("s1 = " + s1);
        System.out.println("s2 = " + s2);
        System.out.println("s3 = " + s3);
        System.out.println("s1 + s2 = " + s1.plus(s2));
        System.out.println("s3 + s2 = " + s3.plus(s2));
        System.out.println("s1 + s2 = " + USMoney.plus(s1, s2));

    }
    
}
