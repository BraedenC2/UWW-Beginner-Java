public class DieDemo {

    public static void main(String[] args) {

        // Declare and create two objects
        Die d1 = new Die();
        Die d2 = new Die();

        // Roll the two dice
        d1.roll();
        d2.roll();

        System.out.println(d1.getSideUp() + "\n" + d2.getSideUp());
        System.out.println("The sum of two sides up is: " + (d1.getSideUp() + d2.getSideUp()));

    }
    
}
