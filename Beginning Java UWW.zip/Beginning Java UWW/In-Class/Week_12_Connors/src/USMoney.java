public class USMoney {

    // Instance variables
    private int dollars;
    private int cents;



    // Methods
    // Constructor
    USMoney(int dollars, int cents){

        this.dollars = dollars;
        this.cents = cents;

        // Ensure that cents is between 0 and 99
        while (this.cents > 100) {
            this.dollars += 1;
            this.cents -= 100;
        }

        while (this.cents < 0){
            this.dollars -= 1;
            this.cents += 100;
        }

    }

    // Define a instance method named plus that adds two USMoney objects
    // s1($12.34) + s2($5.07) = $17.41
    public USMoney plus(USMoney s1) {
        
        int d, c;
        d = s1.dollars + this.dollars;
        c = s1.cents + this.cents;
        USMoney s = new USMoney(d, c);
        return s;

    }

    // Define a static method called plus that adds 2 USMoney objects

    public static USMoney plus(USMoney s1, USMoney s2) {

        int d = s1.dollars + s2.dollars;
        int c = s1.cents + s2.cents;

        return new USMoney(d, c);


    }

    // Override toString()
    public String toString() {  
        
        if (this.cents < 10)
            return "$" + this.dollars + ".0" + this.cents;
        else
            return "$" + this.dollars + "." + this.cents;
    
    }
    
}
