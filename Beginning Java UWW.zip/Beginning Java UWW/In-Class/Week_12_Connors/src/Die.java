public class Die {

    private int sideUp;

    Die () {

        this.sideUp = 1;

    }

    int getSideUp () {

        return this.sideUp;

    }

    void roll() {

        sideUp = (int) (Math.random()*6)+1;

    }
    
}
