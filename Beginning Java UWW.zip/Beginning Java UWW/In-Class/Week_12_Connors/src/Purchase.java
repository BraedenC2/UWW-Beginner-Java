import java.text.DecimalFormat;

public class Purchase {

    private String invoice;
    private double salesAmt, tax;
    final static double RATE = 0.055; // TaxRate = 5.5%

    // Constructor
    Purchase(String invoice, double salesAmt){
        // Determine the 4-digit invoice number
        // For example, invoice = 23;
        this.invoice = invoice;
        this.salesAmt = salesAmt;
        tax = salesAmt * RATE;

        while (this.invoice.length() < 4){
            this.invoice = "0" + this.invoice;
        }
    }

    // Define setInvoice() method

    // Define setSalesAmt() method




    // Define a method named display() to print a Purchase instance
    public void display(){

        DecimalFormat df = new DecimalFormat("");

        System.out.println("Purchase Information:");
        System.out.println("\n\tInvoice No.\t" + this.invoice);


    }
    
}
