import java.util.Scanner;

public class PurchaseDemo {

    public static void main(String[] args) {

        // Getting the invoice number from the user
        // The invoice number input must be between 1 and 9999
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an integer between 1 and 9999: ");
        int UserNum = sc.nextInt();

        while (UserNum < 1 || UserNum > 9999) {

            System.out.println("Enter an integer between 1 and 9999: ");
            UserNum = sc.nextInt();

        }

        // Convert UserNum from an int to a String
        String userString = UserNum+"";


        // Create a Purchase Instance
        Purchase p = new Purchase(userString, 59.99);

        p.display();


    }
    
}
