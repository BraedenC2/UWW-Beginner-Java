import java.text.DecimalFormat;
import java.util.Scanner;

public class Calculator {

    public static void main(String[] args){
        //Step 1: Declare Variables
        double amount, taxRate, tax, total;
        Scanner scan = new Scanner(System.in);
        DecimalFormat dc = new DecimalFormat("$0.00");
        DecimalFormat dc1 = new DecimalFormat("0.00%");

        //Step 2: Getting the User Input
        System.out.println("Enter a purchase amount: ");
        amount = scan.nextDouble();
        System.out.println("Enter the tax rate (e.g., 0.045 for 4.5%): ");
        taxRate = scan.nextDouble();

        //Step 3: Do the Math
        tax = amount * taxRate;
        total = amount + tax;

        //Step 4: Print out the Results
        System.out.println("Payment Information");
        System.out.println("\tPurchase Amount: " + dc.format(amount) +
                "\n\tTax amount: " + dc1.format(taxRate)  + " \t" + dc.format(tax) +
                "\n\tYour total is: " + dc.format(total));

    }
}
