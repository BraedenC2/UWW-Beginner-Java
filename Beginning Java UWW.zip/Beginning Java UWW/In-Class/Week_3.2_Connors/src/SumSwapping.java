/*
Author: Braeden Connors
Purpose: Using module to create number output
 */

import java.util.Scanner;

public class SumSwapping {

    public static void main(String[] args) {

        int userInput, output, ones, tens, swapped;

        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a integer between 1 and 99: ");
        userInput = scan.nextInt();

        ones = userInput % 10;
        tens = userInput / 10;
        swapped = ones*10 + tens;
        output = userInput + swapped;

        System.out.println("You entered: " + userInput);
        System.out.println("The swapped value is: " + swapped);
        System.out.println("The.........." + userInput + " + " + swapped + " = " + output);

       //System.out.println("The sum of the digits is  " + output);
        // System.out.println("The sums of the digits is " + ones + " + " + tens + " = " + output);

    }
}

// End