public class Practice {

    public static void main(String[] args){

        int x1, x2, x3, x4, x;
        x1 = 11;
        x2 = 22;
        x3 = 33;
        x4 = 44;

        System.out.println("x1 = " + x1 + " x2 = " + x2 + " x3 = " + x3 + " x4 = " + x4);

        x = x1;
        x4 = x1;
        x1 = x2;
        x2 = x3;
        x3 = x4;
        x4 = x;
        System.out.println("x1 = " + x1 + " x2 = " + x2 + " x3 = " + x3 + " x4 = " + x4);

    }
}
