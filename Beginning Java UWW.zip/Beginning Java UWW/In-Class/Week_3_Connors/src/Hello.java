 /*
  * Purpose of the program to print Users name
  * Author: Braeden Connors
  * Class: Introduction to Java
  */
 import java.util.Scanner;//for using Scanner class
public class Hello {
    public static void main(String[] args) {
//step 1: declare variables
            double x1, x2, sum; //to hold the input  and output
        String name;
//step 2: getting the input from the user
//declare and create a Scanner object
            Scanner sc = new Scanner(System.in); //declare a Scanner object
//x1 = sc.nextDouble();
            System.out.print("Enter your name");
            name = sc.nextLine();
//step 3: calculations

//step 4: print the result
            System.out.println("Hello " + name + " Have a nice day");

        }
    }

