import java.util.Scanner;

public class Addition2 {

    public static void main(String[] args) {
//step 1: declare variables
        double x1, x2, sum; //to hold the input  and output
//step 2: getting the input from the user
//declare and create a Scanner object
        Scanner sc = new Scanner(System.in); //declare a Scanner object
//x1 = sc.nextDouble();
        System.out.print("Enter two numbers, separated by spaces: ");
        x1 = sc.nextDouble();
        x2 = sc.nextDouble();
//step 3: calculations
        sum = x1 + x2;
//step 4: print the result
        System.out.println("The sum: " + sum);

    }
}
