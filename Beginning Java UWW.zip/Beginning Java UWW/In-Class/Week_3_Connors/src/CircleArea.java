import java.util.Scanner;

public class CircleArea {
    public static void main(String[] args) {
//step 1: declare variables
        double radius, area; //to hold the input  and output
//step 2: getting the input from the user
//declare and create a Scanner object
        Scanner sc = new Scanner(System.in); //declare a Scanner object
//x1 = sc.nextDouble();
        System.out.print("Enter a radius: ");
        radius = sc.nextDouble();
//step 3: calculations
        area = (3.14159 * (radius * radius));
//step 4: print the result
        System.out.println("Your radius is" + radius);
        System.out.println("Your area is " + area);
    }

}
