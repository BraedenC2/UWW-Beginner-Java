import java.util.Scanner;

public class CircleArea2 {
    public static void main(String[] args) {
//step 1: declare variables
        double radius, area, circumference; //to hold the input  and output
        final double pi = 3.14159;
//step 2: getting the input from the user
//declare and create a Scanner object
        Scanner sc = new Scanner(System.in); //declare a Scanner object
//x1 = sc.nextDouble();
        System.out.print("Enter a radius: ");
        radius = sc.nextDouble();
//step 3: calculations
        area = (pi * (radius * radius));
        circumference = 2 * pi * radius;
//step 4: print the result
        System.out.println("Your radius is" + radius);
        System.out.println("Your area is " + area);
        System.out.println("Your circumference is " + circumference);
    }
}
