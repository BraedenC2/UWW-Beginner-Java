import java.text.DecimalFormat;
import java.util.Scanner;

public class FutureTuition {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");

        int year;
        double tuition;

        System.out.print("What year is it?: ");
        year = scanner.nextInt();
        System.out.print("Enter the tuition for the year: ");
        tuition = scanner.nextDouble();

        System.out.println("\tYear\tTuition\n\t----------------------");

        for (int i = 0; i < 10; i++){
            System.out.println("\t" + (year + i) + "\t" + df.format(tuition));
            tuition = tuition + tuition * 0.05;
        }
    }
}
