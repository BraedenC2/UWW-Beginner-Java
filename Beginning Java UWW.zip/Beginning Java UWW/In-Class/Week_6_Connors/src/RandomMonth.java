public class RandomMonth {

    public static void main(String[] args) {

        int x = (int) (Math.random() * (12) + 1);
        String name = switch (x) {
            case 1 -> "Jan";
            case 2 -> "Feb";
            case 3 -> "Mar";
            default -> "null";
        };

        System.out.println("x = " + x + " The month name is " + name);

    }
}