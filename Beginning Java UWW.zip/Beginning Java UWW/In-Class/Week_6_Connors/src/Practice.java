public class Practice {

    public static void main(String[] args){

    // int x, score = 52;
     int x1 = (int) (Math.random()*100), y = (int) (Math.random()*(99 - 10 +1) + 10);

    // x = (3 > 4)? 10: 20;
    // System.out.println("x = " + x);

    // System.out.println((score >= 60)? "Passed!": "Failed!");

     System.out.println(" x1 = " + x1);
     System.out.println(" y = " + y);




    }
}
