import java.util.Scanner;

public class MathQuiz {

    public static void main(String[] args){

        int score = 0;
        for (int i = 0; i < 5; i++){
        int x = (int) (Math.random() * (3) + 1), x1 = (int) (Math.random() * (99 - 10 + 1) + 10),
                x2 = (int) (Math.random() * (99 - 1- + 1) + 10), userAns, temp;
        Scanner scanner = new Scanner(System.in);


            if (x1 < x2) {
                temp = x1;
                x1 = x2;
                x2 = temp;
            }

            System.out.println("What is " + x1 + " - " + x2 + " = ?");

            userAns = scanner.nextInt();
            if (userAns == (x1-x2)){
                score++;
            }

            System.out.println((userAns == (x1-x2))? "Correct!": ("Incorrect!\n" + x1 + " - " + x2 + " = " + (x1 - x2)));
        }

        System.out.println("Your score is: " + score + "/5");

    }
}