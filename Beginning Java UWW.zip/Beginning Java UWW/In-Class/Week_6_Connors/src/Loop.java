public class Loop {

    public static void main(String[] args){

        int count = 0;

        for (int i = 1; i <= 50; i += 2){
            System.out.print(i + "\t");
            count++;
            if (count % 8 == 0){
                System.out.println("");
            }
        }
    }
}
