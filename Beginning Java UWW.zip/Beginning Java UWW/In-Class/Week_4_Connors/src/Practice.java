/* public class Practice {

    public static void main(String[] args){

        int score;

        score = 78;

        if (score < 60){

            System.out.println("Passed! :)");

        } else {

            System.out.println("Failed! :(");

        }

    }

}
*/