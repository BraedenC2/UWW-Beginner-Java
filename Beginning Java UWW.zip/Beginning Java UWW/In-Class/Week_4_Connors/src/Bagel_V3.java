import java.text.DecimalFormat;
import java.util.Scanner;

public class Bagel_V3 {

    public static void main (String[] args){

        int bagels;
        double cost, price;
        final double UNIT1 = 0.60, UNIT2 = 0.75, FIXEDNUM = 6;
        DecimalFormat dc = new DecimalFormat("$0.00");

        System.out.println("Enter the number of Bagels: ");
        Scanner scan = new Scanner(System.in);
        bagels = scan.nextInt();

        if (bagels <= FIXEDNUM){
            cost = bagels * UNIT2;
            System.out.println("Total = " + bagels + " * " + dc.format(UNIT2) + " = " + dc.format(bagels*UNIT2));
        } else {
            cost = 6 * UNIT2 + (bagels - 6) * UNIT1;
            System.out.println("Total = " + 6 + " * " + UNIT2 + ") + (" +  (bagels-6) + " * " + dc.format(UNIT1) + ") = " + dc.format(cost));
        }


    }
}
