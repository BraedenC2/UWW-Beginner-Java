import java.text.DecimalFormat;
import java.util.Scanner;

public class Payroll {
    public static void main(String[] args) {
//1. Declare variables

        double hrsWorked, payRate, regularPay, overtimePay = 0, grossPay;
        String over60 = "No";
        final double HOURS = 40, OVERRATE = 2;

//2. Getting the input from the user
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");
        System.out.print("Enter the hours worked and pay rate, separated by spaces: ");
        hrsWorked = sc.nextDouble();
        payRate = sc.nextDouble();
//3. making calculations
        if (hrsWorked >= HOURS) {
            regularPay = HOURS * payRate;
            overtimePay = (hrsWorked - HOURS) * payRate * OVERRATE;
        } else {
            regularPay = hrsWorked * payRate;
        }
        grossPay = regularPay + overtimePay;

        if (hrsWorked > 60) {

            grossPay += 200;
            over60 = "Yes";

        }

//4. print the results
        System.out.println("\nSummary: ");
        System.out.println("\n\tRegular Pay\t\t" + regularPay );
        System.out.println("\tOvertime Pay\t\t" + overtimePay);
        System.out.println("\tWorked Over 60 Hrs:\t" + over60);
        System.out.println("\tGross Pay\t\t" + grossPay);
    }
}