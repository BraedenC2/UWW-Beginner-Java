public class CountingLetters {

    private int[] counts = new int[26];



    // Methods

    // Constructor

    // Create 100 random upper case letters
    CountingLetters() {
        // Create 100 random upper case letters
        System.out.println("The 100 random upper case letters are: ");
        int x, counter = 0;
        for (int i = 0; i < 100; i++) {
            x = (int)(Math.random()*(90-65+1)+65);  // (char)(65) = 'A', (char)(90)
            counts[x-65]++; // For example, x = 67 --> 'C', x = 85, --> 'U'
            
            System.out.print((char)(x)+" ");
            counter++;
            if (counter == 10) {
                counter = 0; // Reset counter 0
                System.out.println(); // Start a new line
            }
        }
    }


    // Define a printCountingLetters() method
    public void printCountingLetters() {

        System.out.println("\nThe count for each letter:");
        for (int i = 0; i < 26; i++) {
            System.out.print((char)(65+i)+" ");
        }
        System.out.println();

        for (int i = 0; i < 26; i++) {
            System.out.print(counts[i]+" ");
        }

    }
}
