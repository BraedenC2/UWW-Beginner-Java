public class LinearEquation {

        // Instance variables
    private double a, b, c, d, p, q;


    // Methods
    // Constructor
    LinearEquation(double a, double b, double c, double d, double p, double q) {

        this.a = a; this.b = b; this.c = c; this.d = d; this.p = p; this.q = q;

    }

    // Six get methods

    // isSolvable() method
    public boolean isSolvable() {

        /*if((a*d)-(b*c) != 0)
            return true;
        else
            return false;*/

        return (a*d)-(b*c) != 0;

    }

    public double getX() {  return ((p*d - b*q)/(a*d-b*c));    }

    public double getY() { return ((a*q - p*c)/(a*d-b*c));    }
    
}
    

