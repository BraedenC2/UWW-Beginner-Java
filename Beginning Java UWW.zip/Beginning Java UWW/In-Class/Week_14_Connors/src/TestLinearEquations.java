public class TestLinearEquations {

    public static void main(String[] args) {
        Quadratic e = new Quadratic(3, 1, 12, 4, 2, 3);
        // Check if the system is solvable or not
        if (e.isSolvable())
        // If the system is solvable, then print the solutions
            System.out.println("The solution is " + "(" + e.getX() + ", " + e.getY() + ")");
        else
            System.out.println("The system is not solvable");

    }
    
}
