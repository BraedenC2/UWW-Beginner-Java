public class Quadratic {
    // Instance variables
    private double a, b, c;


    // Methods
    // Constructor
    Quadratic(double a, double b, double c) {

        this.a = a; this.b = b; this.c = c;

    }

    // Six get methods

    public double getDiscriminant(){  return ((b*b)-(4*(a*c)));    }

    public double getRoot1(){   return (-b+)} // Ended here for HOMEWORK

    
}
