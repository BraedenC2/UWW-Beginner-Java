public class CountingLettersDemo {

    public static void main(String[] args) {
        
        // Create a CountingLetters object
        CountingLetters c = new CountingLetters();
        c.printCountingLetters();

    }
    
}
