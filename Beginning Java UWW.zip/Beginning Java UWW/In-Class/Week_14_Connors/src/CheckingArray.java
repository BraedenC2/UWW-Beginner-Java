public class CheckingArray {

    public static void main(String[] args) {
        
        
        System.out.println(allSameChar("aaaaaaaaaa"));

    }

    public static boolean allSameChar(String x){
        // For example, x = "aaaAAaa";
        // Assign the first character of x to char c
        x = x.toUpperCase();
        
        char c = x.charAt(0);

        for (int i = 1; i<x.length(); i++){
            if (c != x.charAt(i))
                return false;}
        return true;

    }
    
}
