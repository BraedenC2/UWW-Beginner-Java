import java.util.Scanner;

public class TenInputs {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        int[] x = new int[5];

        for (int i = 1; i <= 5; i++){
            System.out.println("Enter number " + i + " : ");
            x[i-1] = scanner.nextInt();
        }

        System.out.println("The inputs you entered were: " + x[0] + ", " + x[1]);

    }
    
}
