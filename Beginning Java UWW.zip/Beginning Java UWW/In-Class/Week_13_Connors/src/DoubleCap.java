public class DoubleCap {

    public static void main(String[] args) {

        int[] x = {6, 8, 9, 12, 8, 90, 34, 6, 5, 4, 3};
        // Print the original array
        for (int i = 0; i < x.length; i++)
            System.out.print(x[i] + ", ");

        System.out.println("");

        x = doubleCapacity(x);

        // Print array x
        for (int i = 0; i < x.length; i++)
            System.out.print(x[i] + ", ");

    } // End main
    
    // Define doubleCapacity() method
    public static int[] doubleCapacity(int[] x) {
        /*
        For example, x = {3, 5, 7, 10};
        Then the method returns x = {3, 5, 7, 10, 0, 0, 0, 0};
        Declare an int array, whose length is double of x
        */
        int[] newX = new int[5 + x.length];   // If x.length = 4,
        // newX = {0, 0, ..., 0};
        for (int i = 0; i < x.length; i++)
            newX[i] = x[i];
        
        return newX;    // Here, newX is an int array
    }



} // End class
