import java.text.DecimalFormat;

class Complex {
    //create data fields
    private double a, b;

    //constructor
    public Complex(double a, double b) {

        this.a = a;
        this.b = b;
    
    }

    // Define get a method
    public double getA() {return this.a;}
    public double getB() {return this.b;}

    

    // prints the complex object
    public String toString() {

        DecimalFormat df =new DecimalFormat("0.00");
        return "(" + df.format(a) + ")"  + " + "+ "(" + df.format(b) +")" + "i";
}
}