import java.util.Scanner;

public class BuildingLookUp {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        boolean found = false;

        // Create a Building array of length 10
        // int[] x = new int[10];
        Building[] building = new Building[10];
        building[0] = new Building("One World Trade Center", "New York", 1776, 104);
        building[0] = new Building("One World Trade Center", "New York", 1176, 104);
        building[1] = new Building("Willis Tower", "Chicago", 1415, 108);
        building[2] = new Building("Empire State", "New York", 1250, 102);
        building[3] = new Building("Bank of America Tower", "New York", 1200, 55);
        building[4] = new Building("Aon Center", "Chicago", 1136, 83);
        building[5] = new Building("John Hancock Center", "Chicago", 1127, 100);
        building[6] = new Building("Wells Fargo Plaza", "Houston", 992, 71);
        building[7] = new Building("Comcast Center", "Philadephia", 974, 57);
        building[8] = new Building("Columbia Center", "Seattle", 967, 76);
        building[9] = new Building("Key Tower", "Cleveland", 947, 57);
        
        String userIn;

        while (found == false){
            System.out.print("Enter building name: ");
            userIn = scanner.nextLine();
        for (int i = 0; i < building.length; i++){

            if(userIn.equals(building[i].getName())){

            found = true;
            System.out.println(building[i]);    

            }
        }

        if (found == false){
            System.out.println("Not in Database: " + userIn);
        }
    }  
}
}
    

