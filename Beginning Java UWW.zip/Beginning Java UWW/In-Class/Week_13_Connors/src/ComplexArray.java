public class ComplexArray {

    public static void main(String[] args) {
        // Declare a Complex array of length 10
        // int[] x = new int[10];

        Complex[] cArray = new Complex[10];
        //cArray[0] = new Complex(12, 67);
        //cArray[1] = new Complex(45, 89);
        // Assign random numbers to each Complex object
        // Print the cArray
        for (int i = 0; i < cArray.length; i++) {

            cArray[i] = new Complex(Math.random()*100, Math.random()*100);
            System.out.println(cArray[i].toString());

        }

        // Print the cArray array
        System.out.println("All of the complex numbers whose real" +
        "part are less than 50: ");

        for (int i = 0; i < cArray.length; i++) {

            if (cArray[i].getA() > 50);
            System.out.println(cArray[i]);

        }


    }
    
}
