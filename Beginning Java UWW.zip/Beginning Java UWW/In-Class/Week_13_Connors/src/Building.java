public class Building {
    // Instance variables
    private String name, city;
    private int height, stories;

    // Methods
    // Constructor
    Building(String n, String c, int h, int s){

        this.name = n; city = c; height = h; stories = s;

    }

    // Define getName()
    public String getName() {return this.name;}

    public String toString(){
        return name + " of " + city + ", " + stories + " floors and " + height + " feet tall.";
    }
    
}
