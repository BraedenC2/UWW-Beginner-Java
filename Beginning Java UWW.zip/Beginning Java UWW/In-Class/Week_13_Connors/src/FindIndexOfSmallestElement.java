public class FindIndexOfSmallestElement {

    public static void main(String[] args) {
        
        double[] x = {2.4, 6, 9, -12, -4, 7, 9};
        System.out.println("The index of the smallest element is " + 
        indexOfSmallestElement(x));

    }   // End main

    // The method return the indx of the smallest element
    public static int indexOfSmallestElement(double[] x){
        // For example x {3.6, 5.9, 8, 12, 12, 4, 10}
        // The method returns 0

        double smallest = x[0];
        int index = 0;
        for (int i = 1; i < x.length; i++){
            if (x[i] < smallest){
                // Replace the smallest with the current element
                smallest = x[i];
                index = i;
            }
        }
        return index;        
    }
    
}
