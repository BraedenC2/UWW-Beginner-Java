public class ArrayPractice {

    public static void main(String[] args) {
        // Declare an integer array of length 10
        /*
        int[] xArray;   // Declare an int array
        xArray = new int[10];   // Create the array of length 10
        */

        int[] xArray = new int[10]; // Create and declare an int array
        int x = 10;
        // You have declared1- integer variables
        // xArray[0], xArray[1], xArray[2], xArray[3]...

        xArray[8] = 20;
        xArray[3] = 45;
        xArray[2] = 34;

        int[] y = {2, 5, 8, 9, 10};
        // Print the xArray
        for (int i = 0; i < xArray.length; i++)
        System.out.print(xArray[i] + " , ");



    }
    
}
