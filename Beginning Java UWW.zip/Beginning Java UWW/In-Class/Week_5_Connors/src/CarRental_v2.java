import java.util.Scanner;
import java.text.DecimalFormat;
public class CarRental_v2 {
    public static void main(String[] args){
//1. Declare variables
        String modelName = "null";
        double dailyRental, charge;
        final double Cost1 = 55, Cost2 = 85, Cost3 = 125, Gas = 52;
        boolean true;
//2. Getting the user inputs
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");
        System.out.print("Enter a vehicle model to rent:\nW for Jeep Wrangler \nC for Jeep Grand Cherokee \nR for Land Rover -----------: " );

        char carModel = scanner.next().charAt(0);

        System.out.print("\nNumber of days to rent: " );

        int days = scanner.nextInt();

        System.out.print("\nWill you refill the car before returning it (Y or N): ");

        char fillTank = scanner.next().charAt(0);

//3. Determine the carName, dailyPrice, and charge
        /*switch (carModel) {
            case 'W':
            case 'w':
                modelName = "Jeep Wrangler";
                dailyRental = Cost1;
                break;
            case 'C':
            case 'c':
                modelName = "Jeep Grand Cherokee";
                dailyRental = Cost2;
                break;
            case 'R':
            case 'r':
                modelName = "Land Rover";
                dailyRental = Cost3;
                break;
            default:
                modelName = "Invalid car model";
                dailyRental = 0;
        }*/

        if (carModel == 'W' || carModel == 'w') {
            modelName = "Jeep Wrangler";
            dailyRental = Cost1;
        } else if (carModel == 'C' || carModel == 'c') {
            modelName = "Jeep Grand Cherokee";
            dailyRental = Cost2;
        } else if (carModel == 'R' || carModel == 'r') {
            modelName = "Land Rover";
            dailyRental = Cost3;
        } else {
            modelName = "Invalid car model";
            dailyRental = 0;
        }

        charge = days * dailyRental;
//4. Display the rental information
        System.out.println("\n\n\nCar Rental Information:");
        System.out.println("\n\tVehicle Model:\t" + modelName);
        System.out.println("\tRental Days:\t" + days);
        System.out.println("\tDaily Rental:\t" + dailyRental);
        if (fillTank == 'Y' || fillTank == 'y') {
            System.out.println("\tTotal = " + days + " x " + dailyRental + " = " + charge);
        }
        else {
            System.out.println("\tTotal = " + days + " x " + dailyRental + " + " + Gas + " = " + (charge + Gas));
        }
    }//end main method
}//end class