import java.util.Scanner;

public class LoanQualifier {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String status;

        System.out.println("Enter the years on the current job: ");
        int years = scanner.nextInt();
        System.out.println("Enter the salary amount");
        double salary = scanner.nextDouble();

        if ((years > 3) && (salary >= 35000)) {
            System.out.println("You qualify for the loan!");
        } else {
            System.out.println("You do not qualify");
        }
    }
}

