import java.util.Scanner;

public class AvgScores 

{
    
    public static void main(String[] args)

    // Create a ThreeScores object/instance
    {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter three scores: ");
        int a1 = scanner.nextInt();
        int a2 = scanner.nextInt();
        int a3 = scanner.nextInt();


        // Using the default constructore to create t1
        AvgTwoHighest t1 = new AvgTwoHighest(a1, a2, a3);
        //t1.setS1(98);
        System.out.println("t1 is " + t1 + "\nThe average of t1 is " + t1.avgtwohighest());


    }
    
}
