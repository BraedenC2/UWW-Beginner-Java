public class CreateID {
    // Data fields, declare instance varibles
    private String name, address;




    // Methods
    // Create a constructor
    public CreateID(String n, String a){

        name = n;
        address = a;

    }

    // Define a method to fnid the ID, it is an instance method
    public String createID(String name, String address) {
        String id = "";
        //assign the first letter of the name to id
        id += name.charAt(0);
        //find the spaces in the name
        for (int i= 0; i<name.length(); i++)
            if (name.charAt(i) ==' ')
            id += name.charAt(i+1);
        //find the first space in the address
        int fSpace = address.indexOf(" ");
        id += address.substring(0, fSpace);
        return id.toUpperCase();
    }

}
