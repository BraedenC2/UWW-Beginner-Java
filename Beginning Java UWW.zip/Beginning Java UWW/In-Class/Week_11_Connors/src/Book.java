public class Book 

{   // Data fields
    String title, author;
    
    // Constructor
    public Book(String t, String a)

    {   title = t; author = a; }

    // Override toString()
    public String toString()

    {   return "Title: " + title + "\nAuthor: " + author; }}
