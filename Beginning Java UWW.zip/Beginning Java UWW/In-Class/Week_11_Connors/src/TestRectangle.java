public class TestRectangle 
{    public static void main(String[] args)
    
    {   // Declare a Rectangle object/instance
        Rectangle r1 = new Rectangle(); // Not avaible anymore since we added r2's constructor
        System.out.println("r1's area is " + r1.area());

        // I want to change r1's width to 20, length to 30
        // r1.width = 12;
        r1.setWidth(12);
        r1.setLength(30);
        System.out.println("r1's area is " + r1.area() + "The length is " + r1.getLength() + "and the width is " + r1.getWidth());

        // Declare another Rectangle with 12 by 15
        Rectangle r2 = new Rectangle(12, 15);

        // Print r1's area
        System.out.println("r2's area is " + r2.area());
        System.out.println("r2 is " + r2.toString());  }
    
}
