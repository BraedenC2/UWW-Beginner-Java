import java.util.Scanner;
public class ConstructID {
    public static void main(String[] args) {
    Scanner keyIn = new Scanner(System.in);
    System.out.print("Enter your full name: ");
    String name = keyIn.nextLine();
    System.out.print("Enter your complete address: ");
    String address = keyIn.nextLine();

    // Create a CreateID object/instance
    CreateID c1 = new CreateID(name, address);
    // Display the ID by calling createID method
    System.out.println(c1.createID(name, address));
    
    // Create a Pizza object/instace
    Pizza p1 = new Pizza("Pepperoni", 5, 3.4);
    p1.display();




}//end main()

}
    

