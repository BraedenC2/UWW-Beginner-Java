public class RectangleArea {

    public static void main(String[] args){

        // Variables declared inside the body of a method are called local variables
        // In Java, local variables have no default values

        double width = 12, length = 15;

        System.out.println("The area of the rectangle is " + area(width, length));




    }

    public static double area(double a, double b){





    }
    
}
