public class Rectangle {
    // Data fields
    // A variable declared inside the class but outside the body of the method
    // Is called an Instance Variable. It's not declared as static
        private double width = 1.0, length = 1.0; // It is an Instance Variable. Default value = 0
        static int objCount;
    



    // Methods
    // Create a Constructor. It is a special method
    public Rectangle(double width, double length){ // Constructors must have the exact name as the class name

        this.width = width;
        this.length = length;
        objCount ++;
    }

    // Create another Constructor
    public Rectangle() {}

    // SetMethods
    public void setWidth(double width) {
        this.width = width;}

    public void setLength(double length){
        this.length = length;}

    public double getWidth() {return width;}
    public double getLength() {return length;}


    // Define a method to get a Rectangle's area

    public double area() {

        return this.width * this.length;}


    // Override toString method
    public String toString() 
    {   return "[" + width + "*" + length + "]"; }



}
