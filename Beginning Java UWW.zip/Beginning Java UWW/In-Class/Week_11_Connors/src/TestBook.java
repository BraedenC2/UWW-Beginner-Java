public class TestBook 

{   public static void main(String[] args)

    {   // Create a Book instance

        Book b1 = new Book("Why We Sleep" , "Braeden Connors");

        System.out.println("b1 is \n" + b1);    }   }
