public class Pizza {
    // Declare instance variables
    private String topping;
    private int diameter;
    private double price;



    // Methods
    // Create a constructor
    public Pizza(String t, int d, double p) {

        topping = t;
        diameter = d;
        price = p;
        
    }

    // Define a display() method to print the pizza's information

    public void display() {

        System.out.println("You have ordered a pizza with " + topping + " toppping, the diameter is " + diameter + " inches, and the price is " + price + ".");



    }


    
}
