public class AvgTwoHighest {

    private int s1 = 1, s2, s3; // Default values are instance variables


    public AvgTwoHighest(int a1, int a2, int a3) {

        s1 = a1; s2 = a2; s3 = a3;

    }


    public void setS1(int a1) {
        s1 = a1;
    }

    public int getS1() {

        return s1;

    }

    // Find the average
    public double avgtwohighest() {

        if (s2 >= s1 && s3 >= s1)   // s1 is the lowest
        return (s2 + s3)/2.0;
        else if (s1 >= s2 && s3 >= s2)  // s2 is the lowest
        return (s1 + s3)/2.0;
        else    // s3 is the lowest
        return (s1 + s2)/2.0;

    }


    // Overide toString()
    public String toString() {

        return "(" + s1 + ", " + s2 + " , " + s3 + ")";


    }
    
}
