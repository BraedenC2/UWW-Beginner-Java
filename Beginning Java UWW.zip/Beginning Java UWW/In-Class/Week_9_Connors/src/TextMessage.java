public class TextMessage {

    public static void main(String[] args){

        displayMessage("Whitewater", 5);


    }
    public static void displayMessage(String s, int n){

        for (int i = 1; i <= n; i++){
            System.out.println(s);
        }

    }


}
