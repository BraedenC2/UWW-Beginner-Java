public class MethodOverloading {

    public static void main(String[] args){

        max(2, 4);

    }

    public static int max(int x1, int x2){


        return x1;
    }
    public static int max(int x1, int x2, int x3){


        return x1;
    }


}
