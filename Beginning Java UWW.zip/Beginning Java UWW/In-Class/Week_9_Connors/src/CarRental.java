/*
 * CarRental.java
 * Author: Student Name
 * Class: CS172/Section number
 */
import java.util.Scanner;
import java.text.DecimalFormat;
public class CarRental {

    public static char carModel, fillTank;
    public static int days;
    public static String carName = "";
    public static double dailyPrice, charge;
    public static final double GAS = 52.00, COST1 = 55, COST2 = 85, COST3 = 125;

    public static void main(String[] args) {
//1. Declare variables

//2. Getting the user inputs
        Scanner s = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");
        System.out.print("Enter a vehicle model to rent:\n" + "W for Jeep Wrangler \nG for Jeep Grand Cherokee \nR for Land Rover -----------: ");
        carModel = s.next().charAt(0);
        while (carModel != 'W' && carModel != 'w' && carModel != 'G' && carModel != 'g' && carModel != 'R' && carModel != 'r'){

            System.out.println("Car model must br W, G, or R. Enter a car model: ");
            carModel = s.next().charAt(0);


        }

        System.out.print("\nNumber of days to rent: ");
        days = s.nextInt();
        while (days <= 0){
            System.out.println("The days must be positive. Enter the number of days: ");
            days = s.nextInt();

        }



        System.out.print("\nWill you refill the car before returning (Y or N): ");
        fillTank = s.next().charAt(0);
        // calling:

        rentalCharge(carModel, days, fillTank);


    }

    public static void rentalCharge(char carModel, int days, char fillTank) {

        DecimalFormat df = new DecimalFormat("$0.00");
        switch (carModel) {
            case 'W':
            case 'w':
                carName = "Jeep Wrangler";
                dailyPrice = COST1;
                break;
            case 'G':
            case 'g':
                carName = "Jeep Grand Cherokee";
                dailyPrice = COST2;
                break;
            case 'R':
            case 'r':
                carName = "Land Rover";
                dailyPrice = COST3;
                break;
            default:
                System.out.println("Invalid Input!");
                dailyPrice = 0;
                break;
        }//end switch
        charge = dailyPrice * days;
        //4. Display the rental information
        System.out.println("\n\nCar Rental Information:");
        System.out.println("\n\tVehicle Model:\t" + carName);
        System.out.println("\tRental Days:\t" + days);
        System.out.println("\tDaily Rental:\t" + df.format(dailyPrice));
        if (fillTank == 'Y' || fillTank == 'y') {
            System.out.println("\tFill Tank:\t" + "Yes");
            System.out.println("\tTotal = " + days + " x " +
                    df.format(dailyPrice) + " = " + df.format(charge));
        } else {
            System.out.println("\tFill Tank:\t" + "No");
            System.out.println("\tTotal = " + days + " x " +
                    df.format(dailyPrice) + " + "
                    + df.format(GAS) + " = " + df.format(charge + GAS));


        }


    }
}