import java.util.Scanner;

public class TestAdmission {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a GPA: ");
        double gpa = scanner.nextDouble();
        while (gpa < 0.0 || gpa > 4.0) {
            System.out.println("GPA must be between 0.0 and 4.0. Enter a GPA: ");
            gpa = scanner.nextDouble();
        }
        System.out.println("Enter an admission test score: ");
        int score = scanner.nextInt();
        System.out.println("The admission result is " + Admission(score, gpa));

    }

    public static String Admission(int s, double g) {

        String results;
        if (g >= 3.6 && s >= 60)
            results = "Accepted!";
        else if (g >= 2.6 && s >= 80)
            results = "Accepted";
        else
            results = "Rejected";

        System.out.println("The admission result is " + results);
        return results;

    }

}
