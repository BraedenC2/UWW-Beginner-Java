import java.util.Scanner;

    /*public class FindLarge {
        public static void main(String[] args) {
//1. Declare variables
            double num1, num2;
//2. Getting the input from the user
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter two numbers, separated by spaces: ");
            num1 = sc.nextDouble();
            num2 = sc.nextDouble();

            larger - max(num1, num2);
            System.out.println("The larger one is "  + max(num1, num2));
        }

        public static double max(double x1, double x2) {

            double larger;

            if(x1 > x2)
                larger = x1;
                else
                    larger = x2;

            return larger;
        }


    }
*/