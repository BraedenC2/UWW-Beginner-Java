public class TestSum2 {

    public static void main(String[] args){

        int a1 = 4, a2 = 9;
        System.out.println("The total from " + a1 + " to " + a2 + " is " + sum(a1, a2));

        a1 = 20; a2 = 38;
        System.out.println("The total from " + a1 + " to " + a2 + " is " + sum(a1, a2));
                //sum(1, 10);

                sum (20, 38);

                sum (35, 49);


            }//end main()
    public static int sum(int x1,int x2){
        int total = 0;
        for(int i = x1; i<=x2; i++)
            total += i;
        //System.out.println("The total from " + x1 + " to " + x2 + " is " + total);
        return total;




    }




        }//end class


