public class Employee {

    private String name, dep, id, phone;

    Employee(String n, String d, String i, String p){

        name = n;
        dep = d;
        id = i;
        phone = p;

    }

//toString() method
    public String toString() {

        return "Name\t\tDept.\t\tID\t\tPhone\n" +
        this.name + "\t" + this.dep + "\t" + this.id + "\t\t" +
        this.phone;
        
    }

}
