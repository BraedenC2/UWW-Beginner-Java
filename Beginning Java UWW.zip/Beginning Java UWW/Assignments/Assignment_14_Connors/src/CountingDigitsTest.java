public class CountingDigitsTest {

    public static void main(String[] args) {
        
        CountingDigits test = new CountingDigits();
        test.printCounting();


    }
    
}
