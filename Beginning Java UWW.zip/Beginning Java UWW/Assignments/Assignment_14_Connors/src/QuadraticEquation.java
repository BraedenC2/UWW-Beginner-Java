public class QuadraticEquation {

    private double a, b, c, value;

    // Create 100 random upper case letters
    QuadraticEquation(double a, double b, double c) {

        this.a = a;
        this.b = b;
        this.c = c;

    }

    public double getDiscriminant() {

        value = (b*b)-4*a*c;
        return value;

    }

    public double getRoot1(){

        if (value < 0)
            return 0;
        else
            return ((-b)+Math.sqrt((b*b)-4*a*c))/2*a;

    }

    public double getRoot2(){

        if (value < 0)
            return 0;
        else
            return ((-b)-Math.sqrt((b*b)-4*a*c))/2*a;

    }
    
}
