import java.text.DecimalFormat;
import java.util.Scanner;

public class QuadraticEquationTest {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        double a, b, c;
        
        System.out.print("Enter a, b, c:");
        a = scanner.nextDouble();
        b = scanner.nextDouble();
        c = scanner.nextDouble();

        QuadraticEquation qe = new QuadraticEquation(a, b, c);

        System.out.println("The equation has two roots" + df.format(qe.getRoot1()) + " and " + df.format(qe.getRoot2()));




    }
    
}
