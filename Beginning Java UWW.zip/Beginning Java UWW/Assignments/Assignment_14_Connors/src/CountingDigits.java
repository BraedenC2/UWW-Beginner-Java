public class CountingDigits {
    
    private int[] counting = new int[10];



    // Methods

    // Constructor

    // Create 100 random upper case letters
    CountingDigits() {
        // Create 100 random upper case letters
        System.out.println("The 100 random upper case digits are: ");
        int x, counter = 0;
        for (int i = 0; i < 100; i++) {
            x = (int)(Math.random()*(9));  // (char)(65) = 'A', (char)(90)
            System.out.print(x + "\t");
            counting[x]++;

            counter++;
            if (counter == 10) {
                counter = 0; // Reset counter 0
                System.out.println(); // Start a new line
            }
  
        }
    }


    // Define a printCountingLetters() method
    public void printCounting() {

        System.out.println("\nThe count for each Digit:");
        for (int i = 0; i < 10; i++) {
            System.out.print((i)+"'s\t");
        }
        System.out.println();

        for (int i = 0; i < 10; i++) {
            System.out.print(counting[i]+"\t");
        }

    }

}
