import java.text.DecimalFormat;
import java.util.Scanner;

public class SpeedingFineCalc {

    public static void main(String[] args){

        final int OVERLIMIT = 65, OVERUNIT = 5, OVERMPH = 90;
        final double OVERPENTALTY = 220;
        String drivingSpeed, over90 = "No";
        int limitSpeed, clockedSpeed, overMiles;
        double fine;
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");

        System.out.println("Enter the speed limit: ");
        limitSpeed = scanner.nextInt();
        System.out.println("Enter the clocked speed: ");
        clockedSpeed = scanner.nextInt();
        System.out.println("");

        if (limitSpeed >= clockedSpeed) {

            drivingSpeed = "Legal";
            overMiles = 0;
            fine = 0;

        } else {

            drivingSpeed = "Illegal";
            overMiles = clockedSpeed - limitSpeed;
            fine = 65 + overMiles*5;

        }

        if (clockedSpeed > 90){

            over90 = "Yes";
            fine = fine + 200;

        }
        System.out.println("The clocked speed is: " + drivingSpeed);
        System.out.println("Miles over the speed limit: " + overMiles);
        System.out.println("Driving over 90 mph: " + over90);
        System.out.println("The fine is: " + df.format(fine));



    }

}
