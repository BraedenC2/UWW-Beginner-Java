import java.text.DecimalFormat;
import java.util.Scanner;

public class CopyChargeCalc {

    public static void main(String[] args) {

        final double COST1 = 0.05, COST2 = 0.03;
        final int FIXEDCOPY = 100;
        double totalCharge, additionalCopies;
        int numCopies, broken1, broken2;

        Scanner scan = new Scanner(System.in);
        DecimalFormat dc = new DecimalFormat("0.00");
        DecimalFormat dv = new DecimalFormat("$0.00");

        System.out.println("Enter number of copies ordered: ");
        numCopies = scan.nextInt();
        System.out.println("You've made " + numCopies + " copies.");

        if (numCopies > 100){

            additionalCopies = numCopies - FIXEDCOPY;
            totalCharge = (FIXEDCOPY * COST1) + (additionalCopies * COST2);
            System.out.println("The total charge is " + "(" + "100" + " * " + dv.format(COST1)+ ")" + " + " + "(155"  + " * " + COST2 + ") = " + dv.format(totalCharge));

        } else {

            totalCharge = numCopies * COST1;
            System.out.println("The total charge is: " + numCopies + " * $" + COST1 + " = " + totalCharge);

        }


    }

}
