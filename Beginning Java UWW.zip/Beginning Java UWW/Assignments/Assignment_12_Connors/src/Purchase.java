import java.text.DecimalFormat;

public class Purchase {

    DecimalFormat decimalFormat = new DecimalFormat("$0.00");

    private String invoice;
    private double salesAmt, tax, totalAmount;
    final static double RATE = 0.055; // TaxRate = 5.5%

    // Constructor
    Purchase(String invoice, double salesAmt){
        // Determine the 4-digit invoice number
        // For example, invoice = 23;
        this.invoice = invoice;
        this.salesAmt = salesAmt;
        this.tax = salesAmt * RATE;
        totalAmount = this.salesAmt + this.tax;

        while (this.invoice.length() < 4){
            this.invoice = "0" + this.invoice;
        }
    }



    // Define a method named display() to print a Purchase instance
    public void display(){

        DecimalFormat df = new DecimalFormat("");

        System.out.println("Purchase Information:");
        System.out.println("\n\tInvoice No.\t" + this.invoice);
        System.out.println("\tSale Amount\t" + decimalFormat.format(this.salesAmt));
        System.out.println("\tTax\t" + decimalFormat.format(this.tax));
        System.out.println("\tTotal Amount\t" + decimalFormat.format(this.totalAmount));


    }
    
}
