public class Complex {

    // Instance variables
    private double x;
    private double y;

    Complex(double real, double imaginary) {

        this.x = real;
        this.y = imaginary;

    }

    public Complex add(Complex s1) {
        
                

    }

    // Define a static method called plus that adds 2 USMoney objects

    public static USMoney plus(USMoney s1, USMoney s2) {

        int d = s1.dollars + s2.dollars;
        int c = s1.cents + s2.cents;

        return new USMoney(d, c);


    }

    // Override toString()
    public String toString() {  
        
      
    
    }
    
}

    


}
