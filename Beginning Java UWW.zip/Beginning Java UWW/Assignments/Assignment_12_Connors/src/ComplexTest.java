public class ComplexTest {

    public static void main(String[] args) {

        Complex c = new Complex(3, 12);
        System.out.println(c);

    }
    
}
