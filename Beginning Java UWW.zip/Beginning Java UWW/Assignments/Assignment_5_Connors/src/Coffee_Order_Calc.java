import java.text.DecimalFormat;
import java.util.Scanner;

public class Coffee_Order_Calc {

    public static void main(String[] args) {
        int bags;
        final double D1 = 0.05, D2 = 0.1, D3 = 0.15, D4 = 0.2, D5 = 0.25, D6 = 0.3;
        final double B1 = 25, B2 = 50, B3 = 100, B4 = 150, B5 = 200, B6 = 300;
        double costbeforediscound = 0, discount = 0, amountdiscount = 0;
        final double price = 15.50;

        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");
        DecimalFormat df2 = new DecimalFormat("0.00");

        System.out.println("Enter the number of bags you'd like: ");
        bags = scanner.nextInt();

        if (bags >= B1){
            costbeforediscound = bags * price;
            discount = D1 * costbeforediscound;
            amountdiscount = 5.00;
        } else if (bags >= B2){
            costbeforediscound = bags * price;
            discount = D2 * costbeforediscound;
            amountdiscount = 10.00;
        } else if (bags >= B3){
            costbeforediscound = bags * price;
            discount = D3 * costbeforediscound;
            amountdiscount = 15.00;
        } else if (bags >= B4){
            costbeforediscound = bags * price;
            discount = D4 * costbeforediscound;
            amountdiscount = 20.00;
        } else if (bags >= B5){
            costbeforediscound = bags * price;
            discount = D5 * costbeforediscound;
            amountdiscount = 25.00;
        } else if (bags >= B6) {
            costbeforediscound = bags * price;
            discount = D6 * costbeforediscound;
            amountdiscount = 30.00;
        }
        System.out.println("Bags ordered: " + bags);
        System.out.println("Cost before discount: " + df.format(costbeforediscound));
        System.out.println("Discount: " + df.format(discount) + " (" + df2.format(amountdiscount) + "% off)");

        System.out.println("\nTotal: " + df.format(costbeforediscound) + " - " + df.format(discount) + " = " + df.format((costbeforediscound - discount)));


    }


}
