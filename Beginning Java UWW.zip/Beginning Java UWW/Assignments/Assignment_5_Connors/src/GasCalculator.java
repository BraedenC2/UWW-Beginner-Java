import java.text.DecimalFormat;
import java.util.Scanner;

public class GasCalculator {

    public static void main(String[] args) {

        char gasGrade;
        String gasName = "null";
        double price = 0, charge, noGallons;


        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");

        System.out.println("Enter gas grade, \nR for regular, M for Midgrade, P for Premium: ");
        gasGrade = scanner.next().charAt(0);
        System.out.println("Enter the number of gallons: ");
        noGallons = scanner.nextDouble();

        switch (gasGrade){
            case 'R':
            case 'r':
                gasName = "Regular";
                price = 3.09;
                break;
            case 'M':
            case 'm':
                gasName = "Midgrade";
                price = 3.59;
                break;
            case 'P':
            case 'p':
                gasName = "Premium";
                price = 3.99;
                break;
            default:
                System.out.println("Error: \nInvalid Gas Grade");
        }

        charge = price * noGallons;


        System.out.println("Purchase Information: \n\tYou purchased " + noGallons + " gallons of " + gasName + " gas at " +
                df.format(price) + " per gallon. \nYour payment is: " + df.format(charge));



    }

}
