import java.util.Scanner;

public class Conversion{
        public static void main(String[] args){
            double pounds, kilograms;
            Scanner scan = new Scanner(System.in);

            System.out.println("Please enter amount of pounds you'd like to convert:");
            pounds = scan.nextDouble();
            kilograms = pounds * 0.454;
            System.out.println(pounds + " Pounds in Kilograms is: " + kilograms);


        }//End Main Method
    }// End Class
