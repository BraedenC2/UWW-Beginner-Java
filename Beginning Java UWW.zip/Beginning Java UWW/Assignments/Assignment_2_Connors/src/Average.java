import java.text.DecimalFormat;
import java.util.Scanner;

public class Average {

    public static void main(String[] args){
     double number1, number2, number3, average;
     DecimalFormat dx = new DecimalFormat("0.000");
     Scanner scan = new Scanner(System.in);

     System.out.println("Hello. Please enter 3 numbers for an average: ");
     System.out.println("Enter your first number: ");
     number1 = scan.nextDouble();
     System.out.println("Enter your first number: ");
     number2 = scan.nextDouble();
     System.out.println("Enter your first number: ");
     number3 = scan.nextDouble();
     average = (number1 + number2 + number3)/3;
     System.out.println("Your average is: " + dx.format(average));


    }
}
