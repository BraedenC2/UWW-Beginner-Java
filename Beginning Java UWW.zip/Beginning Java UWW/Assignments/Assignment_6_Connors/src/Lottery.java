import java.text.DecimalFormat;
import java.util.Scanner;

public class Lottery {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("$0.00");

        int lottery = (int) (Math.random() * (90) + 10), guess, guessdig1, guessdig2;
        final double prize1 = 10000, prize2 = 3000, prize3 = 1000;
        int digit1, digit2;

        System.out.println("Enter your lottery number (two digits): ");
        guess = scanner.nextInt();
        System.out.println("The lottery number is: " + lottery + ".\nYour guess is: " + guess);
        digit1 = lottery % 10;
        digit2 = lottery % 100 / 10;
        guessdig1 = guess % 10;
        guessdig2 = guess % 100 / 10;

        if (guess == lottery){
            System.out.println("You won: " + df.format(prize1) + "!!!");
        } else if (((guessdig1 == digit1) && (guessdig2 == digit2)) || ((guessdig1 == digit2) && (guessdig2 == digit1))){
            System.out.println("You won: " + df.format(prize2) + "!!");
        } else if (((guessdig1 == digit1) || (guessdig2 == digit2))){
            System.out.println("You won: " + df.format(prize3) + "!");
        } else {
            System.out.println("Sorry, no prize.");
        }



    }

}
