import java.text.DecimalFormat;
import java.util.Scanner;

public class CheckPosandNeg {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        int userIn, PosNum = 0, NegNum = 0, sum = 0;
        double average;

        System.out.println("Enter an Integer, enter 0 to exit: ");
        userIn = scanner.nextInt();

        if (userIn == 0){

            System.out.println("No numbers are entered except 0");

        } else {

            while (userIn != 0) {

                if (userIn > 0) {

                    PosNum++;

                } else if (userIn < 0) {

                    NegNum++;

                }

                sum += userIn;
                System.out.print("Enter an Integer, enter 0 to quit: ");
                userIn = scanner.nextInt();

            }
        }

        average = (double) sum / (PosNum + NegNum);

        System.out.println("The number of positives is: " + PosNum);
        System.out.println("The number of negatives is: " + NegNum);
        System.out.println("The total is: " + sum);
        System.out.println("The average is: " + df.format(average));





    }




}
