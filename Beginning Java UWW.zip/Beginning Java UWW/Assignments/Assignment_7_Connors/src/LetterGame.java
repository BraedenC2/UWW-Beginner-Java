import java.util.Scanner;

public class LetterGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int x = (int) (Math.random()*(90 - 65 + 1) + 65), count = 1;
        char guess1, answer = (char) x;
        int guess;


        do {

            System.out.println("I am thinking of a letter between A and Z. Can you guess it: ");
            System.out.println(x);
            guess1 = scanner.next().charAt(0);
            guess = guess1;

            if (guess == x) {

                System.out.println("Yes, the letter is " + answer);

            } else if (guess < x) {

                System.out.println("Your guess is too low");
                count++;

            } else if (guess > x) {

                System.out.println("Your guess is too high !!");
                count++;

            } else {
                System.out.println("The letter must be in between A and Z! \nTry again!");
            }

        } while (guess != x);

        System.out.println("Congrats! You got it in " + count + " guesses");


    }


}
