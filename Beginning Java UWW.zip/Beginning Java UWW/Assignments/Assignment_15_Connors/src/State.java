import java.text.DecimalFormat;

public class State {

    private String name;
    private int pop, area;
    private double density;

    DecimalFormat df = new DecimalFormat("0.00");
    
    State(String n, String p, String a) {


        name = n;
        pop = Integer.parseInt(p);
        area = Integer.parseInt(a);
        density = pop/area;

    }

    public String toString() {

        return "State Name\tArea(sq mi)\tPopulation\tDensity(per qe mi)\n" +
        this.name + "\t" + this.area + "\t\t" + this.pop + "\t\t" + 
        df.format(this.density); 
    

    }
    
}
