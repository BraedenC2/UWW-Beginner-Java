import java.io.File;
import java.util.Scanner;
public class StateSearch {

    public static void main(String[] args) throws Exception {
        
        char answer = 'Y';
        while (answer == 'Y' || answer == 'y'){

        Scanner scanner = new Scanner(System.in);   // Reading data from the keykoard

        System.out.print("Enter a state name: ");
        String name = scanner.nextLine();

        // Create a File object
        File infile = new File("StateInfo.txt");
        // Create a Scanner object
        Scanner finput = new Scanner(infile);   // Reading data from the file

        boolean found = false;  

        while (finput.hasNext()){

            String inputLine = finput.nextLine();
            // Split the input line to a String array
            String[] item = inputLine.split(",");
            String[] nums = inputLine.split(",");
            // Item[0] = name, item[1] = dep, item[2] = id, item[3] = phone
            // Print the input line
            if (item[0].toUpperCase().indexOf(name.toUpperCase()) != -1){

                found = true; // Found the person

                // Create an Employee object
                State e = new State(item[0].trim(), item[1].trim(), item[2].trim());
                
                System.out.println(e.toString());
            } 

        }

        if (found == false)
            System.out.println("The state was not found!!");

        System.out.println("Do you want to find another ? (Y or N)");
        answer = scanner.next().charAt(0);
        }
    }
    
}


