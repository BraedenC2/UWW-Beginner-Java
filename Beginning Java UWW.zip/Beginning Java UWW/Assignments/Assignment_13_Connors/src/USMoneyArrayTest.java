public class USMoneyArrayTest {

    public static void main(String[] args) {

        int[] doll = {72, 55, 5, 65, 52, 11, 49, 68, 50};
        int[] cen = {53, 15, 27, 66, 78, 68, 33, 37, 40, 60};

        System.out.println("The 10 random USMoneys are: ");
        
        for (int i = 0; i < 9; i++) {

            System.out.print("$" + doll[i] + "." + cen[i] + " ");

        }

        int x = 0;

        System.out.println("\nThe USMoneys less than $50 are:\n");

        while (x != 9){

            USMoneyArray test = new USMoneyArray(doll[x], cen[x]);
            System.out.print(test);
            x++;

        }


    }
    
}
