import java.util.Scanner;

public class StudentArray {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        String[] name = {"Kevin Lang", "Joe Hazelton", "Jean Hooton",
                        "Susan Fowler", "Henry Cusworth", "Hans Denton",
                        "Jared Simmons", "Debra Beamer", "Gary Bradley",
                        "Glen Genson"};
        int[] id = {5658, 8451, 1302, 7580, 7541, 2850, 7589, 1254, 2898, 2771};
        double[] gpa = {3.23, 3.12, 2.98, 3.98, 2.89, 3.76, 3.23, 3.22, 3.84, 2.15};
        
        System.out.println("Enter an ID number: ");
        int idinput = scanner.nextInt();
        boolean found = false;

        for (int i = 0; i < 10; i++){

            if (id[i] == idinput){
                
                Student student = new Student(name[i], id[i], gpa[i]);
                System.out.println(student);
                found = true;
                
            }

        }

        while (found == false){

            System.out.println("Sorry, no student with ID# " + idinput);
            System.out.println("Enter an ID number: ");
            idinput = scanner.nextInt();

            for (int i = 0; i < 10; i++){

                if (id[i] == idinput){
                    
                    Student student = new Student(name[i], id[i], gpa[i]);
                    System.out.println(student);
                    found = true;
                    
                }
    
            }

        }


    }


}
