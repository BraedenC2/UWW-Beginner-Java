public class Student {

    String name;
    int idNum;
    double gpa;

    Student (String name, int idNum, double gpa) {

        this.name = name;
        this.idNum = idNum;
        this.gpa = gpa;


    }

    public String toString () {

        return "ID # " + this.idNum + ", " + this.name + ", " + this.gpa;

    }

    
}
