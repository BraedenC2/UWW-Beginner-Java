public class USMoneyArray {

    private int dollars, cents;
    public char[] toString;

    USMoneyArray ( int dollars, int cents ) {

        this.dollars = dollars;
        this.cents = cents;

    }

    public String toString(){

        if (this.dollars < 50)
        return "$"+this.dollars+"."+this.cents+" ";
        else
        return "";
    }


    
}
