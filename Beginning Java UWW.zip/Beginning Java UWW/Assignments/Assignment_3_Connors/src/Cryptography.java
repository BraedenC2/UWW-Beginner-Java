import java.util.Scanner;

public class Cryptography {

    public static void main(String[] args){

     int input, one, ten, one2, one3, total;
        Scanner scan = new Scanner(System.in);

        System.out.println("Please choose a number from 1 - 99: ");
        input = scan.nextInt();

        one = (input%10);
        ten = (input/10);

        one2 = (one + 7) % 10;
        one3 = (ten + 7) % 10;
        total = one2 + one3;

        System.out.println("The encrypted number is: " + null);
        System.out.println("The double of the encrypted number is: " + null);




    }
}
