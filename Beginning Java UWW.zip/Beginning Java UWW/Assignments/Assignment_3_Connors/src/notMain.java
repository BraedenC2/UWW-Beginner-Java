import java.text.DecimalFormat;
import java.util.Scanner;

public class notMain {

    public static void main(String[] args){


        int x = 0;

        if (x > 0) ;

        {

            System.out.println("x");

        }





    }
}