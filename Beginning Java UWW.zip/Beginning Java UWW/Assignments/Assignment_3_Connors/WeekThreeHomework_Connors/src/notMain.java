import java.text.DecimalFormat;
import java.util.Scanner;

public class notMain {

    public static void main(String[] args){

        double monthlyPayment, loanAmount, yearlyRate, numberOfYears, totalPayment, totalInterest, a;
        Scanner scan = new Scanner(System.in);
        DecimalFormat dfb = new DecimalFormat("$0.00");
        DecimalFormat dfp = new DecimalFormat("0.00%");

        System.out.println("Enter Loan Amount: ");
        loanAmount = scan.nextDouble();
        System.out.println("Enter yearly interest rate: ");
        yearlyRate = scan.nextDouble();
        System.out.println("Enter number of years returning the loan: ");
        numberOfYears = scan.nextDouble();

        monthlyPayment = (loanAmount * yearlyRate/12) / (1 - 1/Math.pow((1 + yearlyRate/12), numberOfYears*12));
        a = (1 + yearlyRate/12);
        totalPayment = monthlyPayment * numberOfYears * 12;
        totalInterest = totalPayment - loanAmount;

        System.out.println("Payment Information:" +
                "\n\tLoan amount: \t" + dfb.format(loanAmount) +
                "\n\tMonthly Payment: \t" + dfb.format(monthlyPayment) +
                "\n\tTotal Interest: (" + dfp.format(totalInterest) + ")\t" +
                "\n\tTotal Payment: \t" + dfb.format(totalPayment));





    }
}