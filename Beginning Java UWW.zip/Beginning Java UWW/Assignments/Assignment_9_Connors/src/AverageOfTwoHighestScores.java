import java.util.Scanner;

public class AverageOfTwoHighestScores {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter three scores each between 0 and 100 inclusive, separated by spaces: ");

        int s1 = scanner.nextInt();
        int s2 = scanner.nextInt();
        int s3 = scanner.nextInt();

        while ((s1 > 100 || s1 < 0) || (s2 > 100 || s2 < 0) || (s3 > 100 || s3 < 0)){

            System.out.print("Enter three scores each between 0 and 100 inclusive, separated by spaces: ");
            s1 = scanner.nextInt();
            s2 = scanner.nextInt();
            s3 = scanner.nextInt();

        }

        AvgTwoHighest(s1, s2, s3);

    }//end main()

    //define a method that returns the larger one between two numbers
    public static void AvgTwoHighest(int s1, int s2, int s3) {
        double Avg = 0;//declare a local variable
//method body goes here

        if ((s1 > s2 && s1 > s3)) {

            if (s2 > s3)
                Avg = (double) (s1 + s2)/2;
            else if (s3 > s2)
                Avg = (double) (s1 + s3)/2;

        } else if ((s2 > s1 && s2 > s3)){

            if (s1 > s3)
                Avg = (double) (s2 + s1)/2;
            else if (s3> s1)
                Avg = (double) (s2 + s3)/2;

        } else if ((s3 > s1 && s3 > s2)){

            if (s1 > s2)
                Avg = (double) (s3 + s1)/2;
            else if (s2 > s1)
                Avg = (double) (s3 + s2)/2;
        } else
            System.out.println("Error");


        System.out.print("The Average of the two highest scores is: " + Avg);

    }//end class

}
