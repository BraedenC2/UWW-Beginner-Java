import java.text.DecimalFormat;
import java.util.Scanner;

public class LawnCare {

    public static void main(String[] args){

        final double FEE1 = 25, FEE2 = 35, FEE3 = 50, SIZE1 = 400, SIZE2 = 600, SER1 = 0, SER2 = 5, SER3 = 3;
        DecimalFormat df = new DecimalFormat("0.00");

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the lot size  in square feet: ");
        int lotsize = scanner.nextInt();

        while (lotsize < 0){
            System.out.println("Enter the lot size  in square feet: ");
            lotsize = scanner.nextInt();
        }

        System.out.println("Enter the number of times you want to pay the bill for the season.");
        System.out.println("1 for once");
        System.out.println("2 for twice");
        System.out.println("20 for 20 times ---------: ");
        int paybill = scanner.nextInt();

        while (paybill != 1 && paybill != 2 && paybill != 20){
            System.out.println("The number of payments must be 1, 2, or 20!");
            System.out.println("Enter the number of times you want to pay the bill for the season.");
            System.out.println("1 for once");
            System.out.println("2 for twice");
            System.out.println("20 for 20 times ---------: ");
            paybill = scanner.nextInt();
        }

        int weeklyFee = 0;
        if (lotsize < 400){
            weeklyFee = 25;
        } else if (lotsize < 600){
            weeklyFee = 35;
        } else if (lotsize >= 600){
            weeklyFee = 50;
        }

        int servicePerPay = 0;
        if (paybill == 1){
            servicePerPay = 0;

        } else if (paybill == 2){
            servicePerPay = 5;

        } else if (paybill == 20){
            servicePerPay = 3;

        }

        double amountpp = (paybill * servicePerPay) * weeklyFee;

        System.out.println("Lawn Mowing Information:");
        System.out.println("\tThe lot size: \t" + lotsize + "(Sq Ft)");
        System.out.println("\tNumber of payments: \t" + paybill);
        System.out.println("\tWeekly mowing fee: \t$" + df.format(weeklyFee));
        System.out.println("\tService charge per payment: \t$" + df.format(servicePerPay));
        System.out.println("\tAmount per payment: \t$" + amountpp);
        double total = paybill * amountpp;
        System.out.println("Total payment = " + paybill + " * " + df.format(amountpp) + " = $" + df.format(total));


    }//end RentalCharge() method
}//end class

