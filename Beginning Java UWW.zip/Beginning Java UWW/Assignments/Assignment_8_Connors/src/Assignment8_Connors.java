import java.text.DecimalFormat;
import java.util.Scanner;

public class Assignment8_Connors {

    public static void main(String[] args){

                char answer ;
                Scanner sc = new Scanner(System.in);
                DecimalFormat df = new DecimalFormat("0.00");
                double a = 0, b =0, c = 0;
                do{
                    System.out.print("Enter 3 sides, use the spacebar to separate each number: ");
                    a = sc.nextDouble();
                    b = sc.nextDouble();
                    c = sc.nextDouble();
                    while (!((a+b)>c && (b+c) > a && (a + c) > b)){
                        System.out.print("\nThe 3 sides entered can not form a triangle. \nEnter 3 sides, use the spacebar to separate each number: ");
                        a = sc.nextDouble();
                        b = sc.nextDouble();
                        c = sc.nextDouble();
                    }
                    double s = (a + b + c)/2;
                    double area = (Math.sqrt(s*(s-a)*(s-b)*(s-c)));
                    System.out.println("\nThe 3 sides entered can form a triangle. \nThe area of the triangle is " + df.format(area) );
                            System.out.print("\nDo you want to do this again: (Y or N ) ? ");
                    answer = sc.next().charAt(0);
                }while (answer == 'Y' || answer =='y');
            }
        }
