public class AdmissionTest {

    public static void main(String[] args){

        Admission a = new Admission(3.0, 80);

        System.out.println(a);


    }
    
}
