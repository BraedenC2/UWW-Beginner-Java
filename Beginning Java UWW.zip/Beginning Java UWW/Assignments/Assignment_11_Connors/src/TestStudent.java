public class TestStudent {

    public static void main(String[] args) {

        StudentClass sc1 = new StudentClass("Susan Meyers", 47899, "Accounting", 3.05);
        StudentClass sc2 = new StudentClass("Mark, Jones", 39119, "Computer Science", 3.89);
        StudentClass sc3 = new StudentClass("Joy Rogers", 81774, "History", 3.65);

        System.out.println("The 3 students are: ");
        System.out.println(sc1);
        System.out.println(sc2);
        System.out.println(sc3);




    }
    
}
