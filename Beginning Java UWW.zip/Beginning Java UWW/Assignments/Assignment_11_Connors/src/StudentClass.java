public class StudentClass {
    
    private String name;
    private int idNum;
    private String major;
    private double gpa;

    public StudentClass(String n, int i, String m, double g){

        name = n;
        idNum = i;
        major = m;
        gpa = g;


    }
    
    public StudentClass(){  }

    public void getName(String n){    }
    
    public void setName(String n){    }

    public void getIdNum(int i){    }

    public void setIdNum(int i){    }

    public void getMajor(String m){     }

    public void setMajor(String m){     }

    public void getGpa(double g){     }

    public void setGpa(double g){     }

    // I don't know what the above is nessesary. It works without those methods. 

    public String toString(){ return "\nName: \t" + name + "\nID: \t" + idNum + "\nMajor: \t" + major + "\nGPA \t" + gpa;} 

}
