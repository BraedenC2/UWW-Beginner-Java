public class Admission {

    private double gpa;
    private int score;
    private String AR;

    Admission(double g, int s){

        gpa = g;
        score = s;
        evalulate();

    }

    public void evalulate() {

        if ((gpa >= 3.0) && (score >= 60))
            AR = "Accepted";
        else if ((gpa < 3.0) && (score >= 80))
            AR = "Accepted";
        else
            AR = "Reject";

    }

    public String toString() { return "GPA " + gpa + ", Score: " + score + " " + AR; }
    


}
