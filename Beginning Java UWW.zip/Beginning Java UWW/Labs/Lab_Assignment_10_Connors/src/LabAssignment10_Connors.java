import java.util.Scanner;

public class LabAssignment10_Connors {

    public static void main(String[] args){

        String fullname = "", address1 = "";

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter you full name: ");
        fullname = scanner.next();

        System.out.println(" Null ");
        address1 = scanner.next();

        createID(fullname, address1);
    }

    public static String createID(String name, String address){

        String lettername = "";

        for (int i = 0; i < name.length()-1; i++){

            if (name.charAt(i) == ' ') {

                lettername += (name.charAt(i+1)+"").toUpperCase();
            }}

        return lettername;



    }
}
