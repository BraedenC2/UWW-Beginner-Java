import java.text.DecimalFormat;
import java.util.Scanner;

public class LabAssignment8_Connors {

    public static void main(String[] args){

        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.000");
        DecimalFormat dc = new DecimalFormat("0.00");

        int x = 1; double y = 1.00;

        do {
            System.out.println("Enter a number: ");
            x = scanner.nextInt();
        } while (x > 0);

        while (y > 0.001){

            y = y / 2.00;
            System.out.println(df.format(y));

        }

        int z = 1, b = -1, c = 0;

            while (c <= 25) {
                System.out.println(z);
                System.out.println(b);
                c++;
            }

        System.out.println("Enter the current year tuition: ");
        double tuition = scanner.nextDouble();
        int years = 0;
        double dubtuition = tuition * 2;
        while (tuition < dubtuition)
        {
            tuition = tuition*1.07; //tuition increased 7% each year
            years ++;
        }//end while loop
        System.out.println("Tuition will be doubled to " + dc.format(tuition) +  " in " + years +   " years.");


    }

}
