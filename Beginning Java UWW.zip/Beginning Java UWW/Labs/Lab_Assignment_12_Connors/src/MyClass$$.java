public class MyClass$$ {

    private int x = 3;
    private boolean b = false;


    //constructor
    MyClass$$ (boolean b) {this.b = b;}

    void doIt() {}

    int dontDoIt() { return this.x; }

}
