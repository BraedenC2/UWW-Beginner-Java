public class main {

    public static void main(String[] args) {
        
        GasTank gt = new GasTank(15);

        System.out.println(gt.addGas(12) + " " + gt.useGas(7.2) + " " + gt.getGasLevel());
       

    }
    
}
