public class GasTank {

    private double amount = 0;
    private double capacity;

    GasTank(double capacity) {

        this.capacity = capacity;



    }

    public double addGas(double amount) {

        this.amount += amount;

        if (this.amount >= this.capacity){
            this.amount = this.capacity;
        }

        return this.amount;



    }

    public double useGas(double amount) {

        this.amount -= amount;

        if (this.amount <= 0){
            this.amount = 0;
        }
        return amount;

    }

    public boolean isEmpty(){

        if (amount < 0.1)
        return true;
        else 
        return false;
        
    }

    public boolean isFull(){

        if (amount > (capacity - 0.1))
        return true;
        else 
        return false;

    }

    public double getGasLevel(){

        return amount;

    }


    
}
