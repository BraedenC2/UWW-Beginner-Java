import java.text.DecimalFormat;
import java.util.Scanner;

public class TemperatureConversionChart {

    public static void main(String[] args){

        int f;

        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("Enter the temperature in degrees Fahrenheit (\u00B0F): ");
        f = scanner.nextInt();

        System.out.println("Conversion Chart");
        System.out.println("\t\u00B0F\t\u00B0C");
        System.out.println("-----------");

        int e = f + 70;

        for (int i = f; f <= e; f += 5){

            double celcius = (double) (5*(f-32))/(9);
            System.out.println("\t" + f + "\t" + df.format(celcius));


        }




    }

}
