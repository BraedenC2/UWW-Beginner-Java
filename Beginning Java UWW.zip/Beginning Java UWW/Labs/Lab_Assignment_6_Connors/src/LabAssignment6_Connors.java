public class LabAssignment6_Connors {

    public static void main(String[] args) {

        int x = 0, k = 0;
        int i;
        double wages = 1, hours = 1;

        for (i = 1; i <= 10; i++) {
            x = (int) (Math.random() * (99 + 1) + 0);
            System.out.println(x);
        }

        for (x = 1; x <= 10; x++) {
            System.out.println(x);
        }

        for (k = 1; k <= 32; k++) {
            System.out.print("*");
        }

        for (i = 121; i >= 21; i -= 5) {

            if (i % 2 != 0) {
                System.out.print(i + " ");
            }
        }

        wages =(hours > 40)? wages*1.5: wages*1;

        System.out.println(wages);


    }
}
