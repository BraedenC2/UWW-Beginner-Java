public class LabAssignment13_Connors {

    public static void main(String[] args) {
        
        int[] arr = new int[31];
        int[] xArray = {1, 2, 3};
        int[] yArray = {4, 5, 6};
        int[] zArray = new int[xArray.length];
        int[] test = {1, 2, 3, 6, 4};

        for (int i = 1; i < arr.length; i++) {

           arr[i] += i;

            if (arr[i]%2 == 0)
                System.out.println("-" + arr[i]);
            else
                System.out.println(arr[i]);

        }

        for (int i = 0; i < zArray.length; i++)
            zArray[i] = xArray[i];
        for (int i = 0; i < zArray.length; i++)
            System.out.print(zArray[i] + ", ");
        for (int i = 0; i < zArray.length; i++)
            zArray[i] = yArray[i];
        for (int i = 0; i < zArray.length; i++)
            System.out.print(zArray[i] + ", ");

        System.out.println(checkingArray(test));
        
    }

    public static boolean checkingArray(int[] x){

        for(int i = 0; i < x.length; i++)
            for (int j = i + 1; j < x.length; j++)
                if ( x[j] < x[i])
                    return false;

        return true;
        
    }

    
}
