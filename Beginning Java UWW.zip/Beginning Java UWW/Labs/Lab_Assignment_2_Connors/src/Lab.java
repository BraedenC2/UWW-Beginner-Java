import java.text.DecimalFormat;
import java.util.Scanner;

public class Lab {
    public static void main(String[] args){

        int drivingAge, endingTime, startingTime, differenceTime, children, families;
        double x1, x2, avg;

        Scanner scan = new Scanner(System.in);
        DecimalFormat dc = new DecimalFormat("0.00");

        drivingAge = 16;
        startingTime = 2;
        endingTime = 10;
        differenceTime = startingTime - endingTime;
        children = 286;
        families = 102;

        avg = (double) children/families;

        System.out.println(drivingAge);
        System.out.println(differenceTime);

        System.out.println("Enter value for x1: ");
        x1 = scan.nextDouble();
        System.out.println("x1 is now: " + x1);
        x2 = (x1 + 5);
        System.out.println("X2 is: " + x2 + " and x1 is: " + x1);

        System.out.println("this is the average child per family: " + dc.format(avg));








    }
}
