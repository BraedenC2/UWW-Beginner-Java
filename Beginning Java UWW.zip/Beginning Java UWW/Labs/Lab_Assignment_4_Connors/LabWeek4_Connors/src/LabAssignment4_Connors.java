public class LabAssignment4_Connors {

    public static void main(String[] args){

        double bonus = 0, x = 0, gpa = 3.75;
        int goodsSold = 1500, deansList = 0, age = 64, seniorCitizens = 0, nonSeniorCitizens = 0;
        boolean minimum = false;
        String studentName = "Braeden";

        if (goodsSold > 500000){

            bonus = 10000;

        }
        if (minimum == true) {

            x = 10;

        }
        if (gpa > 3.5) {

            deansList++;
            System.out.println(studentName);

        }
        if (age >= 65) {

            seniorCitizens++;

        } else {

            nonSeniorCitizens++;

        }

        System.out.println(bonus);
        System.out.println(x);
        System.out.println("Senior Citizens: " + seniorCitizens + "\nNon Senior Citizens: " + nonSeniorCitizens);


    }

}
