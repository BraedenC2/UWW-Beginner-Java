/*
Author: Braeden Connors
Purpose: To program with assignment statements and assignment expressions
 */

// Import
import java.util.Scanner;

// Class
public class LabAssignment3_Connors {

    // Main Method
    public static void main(String[] args){

        // Variables
        int bridgePlayers, statement1, price, xdollars, ycents;
        double width1, length1, width2, length2, totalSpaceArea;

        // Scanner
        Scanner scan = new Scanner(System.in);

        // Start of Assignment 1
        bridgePlayers = 12;
        statement1 = bridgePlayers - 4;
        System.out.println("The first statement is: bridgePlayers(12) - 4 = \t" + statement1);
        System.out.println("----------------------------------------------------------");
        // End of Assignment 1

        // Start of Assignment 2
        System.out.println("Please enter a POSITIVE integer: ");
        price = scan.nextInt();
        xdollars = price / 100;
        ycents = price % 100;
        System.out.println(xdollars + " Dollar(s) and " + ycents + " cent(s)");
        System.out.println("----------------------------------------------------------");
        // End of Assignment 2

        // Start of Assignment 3
        System.out.println("Please enter values for \"width1\" and \"length1\": ");
        width1 = scan.nextDouble();
        length1 = scan.nextDouble();
        System.out.println("You chose for \"width1\": \t" + width1 + " \nYou chose for \"length1\": \t" + length1);
        System.out.println("Now, please enter the values for \"width2\" and \"length2\": ");
        width2 = scan.nextDouble();
        length2 = scan.nextDouble();
        System.out.println("You chose for \"width2\": \t" + width2 + " \nYou chose for \"length2\": \t" + length2);
        totalSpaceArea = (width1 * length1) + (width2 * length2);
        System.out.println("Your total space area is: \t" + totalSpaceArea);
        System.out.println("----------------------------------------------------------");
        // End of Assignment 3







    }
}
