public class MyClass{

    private int x;
    private double y;

    public MyClass(int a, double b) {
    x = a;
    y = b; 
    }

}