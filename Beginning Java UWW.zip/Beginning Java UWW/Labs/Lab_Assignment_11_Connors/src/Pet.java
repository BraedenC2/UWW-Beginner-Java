public class Pet {

    private String name;;
    private String animal;
    private int age;


    public Pet(String n, String an, int a){

        name = n;
        animal = an;
        age = a;

    }


    public void display(){

        System.out.println(name + " is a " + animal + ". " + name + " is " + age + " years old.");
        
    }


    
}
