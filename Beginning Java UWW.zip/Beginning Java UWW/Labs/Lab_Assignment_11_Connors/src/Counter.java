public class Counter {

    private static int counter = 0; 

    public void assigncounter(int assignment){

        counter = assignment;

    }

    public void increment(){

        counter++;


    }

    public void decrement(){

        counter--;

    }

    public static int getValue(){

        return counter;

    }


    
}
