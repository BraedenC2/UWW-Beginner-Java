public class LabWeek11_Connors {

    public static void main(String[] args){

        Counter c1 = new Counter();

        c1.increment();
        Counter.getValue();

        Pet p1 = new Pet("Nora", "Cat", 8);
        Pet p2 = new Pet("Clifford", "dog", 20);

        p1.display();
        p2.display();



    }


    
}
