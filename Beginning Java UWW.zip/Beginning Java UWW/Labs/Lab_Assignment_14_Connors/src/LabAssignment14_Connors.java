import java.text.DecimalFormat;
import java.util.Scanner;

public class LabAssignment14_Connors {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("Enter circle #1's radius: ");
        double circle1 = scanner.nextDouble();
        System.out.println("Enter circle #2's radius: ");
        double circle2 = scanner.nextDouble();

        Circle c = new Circle(circle1, circle2);

        System.out.println(df.format(c.getArearadius1()));
        System.out.println(df.format(c.getArearadius2()));
        System.out.println(c.equal());
        System.out.println(c.greaterThan());

    }
}
