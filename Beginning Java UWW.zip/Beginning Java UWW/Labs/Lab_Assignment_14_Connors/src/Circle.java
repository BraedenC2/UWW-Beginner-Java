public class Circle {

    private double radius1, radius2, area;

    Circle(double circle1, double circle2){

        radius1 = circle1;
        radius2 = circle2;

    }
    
    public double getArearadius1() {

        area = Math.PI*radius1*radius1;
        System.out.println("Circle #1 area is: ");
        return area;

    }

    public double getArearadius2() {

        area = Math.PI*radius2*radius2;
        System.out.println("Circle #2 area is: ");
        return area;

    }

    public String equal() {

        System.out.println("Are circle #1 and #2 equal?");

        if (radius1 == radius2){

            return "Yes";

        } else
            return "No";

    }

    public String greaterThan(){

        System.out.println("Is circle #1 greater than circle #2?");

        if (radius1 > radius2)
            return "Yes";
        else
            return "No";

    }




}
