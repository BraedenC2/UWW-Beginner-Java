import java.util.Scanner;

public class LabAssignment {

    public static void main(String[] args){

        boolean isEmpty;
        int numberOfCredits;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a bmi: ");
        double bmi = scanner.nextDouble();

        if (bmi < 18.5) {
            System.out.println("Underweight");

        }else if (bmi >= 18.5 && bmi <= 24.9) {
            System.out.println("Normal");

        }else if (bmi >= 25.0 && bmi <= 29.9) {
            System.out.println("Obesity Grade 1");

        }else if (bmi >= 30.0 && bmi <= 34.9)
            System.out.println("Obesity Grade 2");

        else if (bmi >= 35.0 && bmi <= 39.9) {
            System.out.println("Obesity Grade 3");

        }else {
            System.out.println("Obesity Grade 4");

        }

        System.out.println("------------------------------");
        System.out.println("Credits Program:");

        isEmpty = false;
        numberOfCredits = 4;

        if (isEmpty == false && numberOfCredits == 3) {
            System.out.println("The class is exactly 3 credits and is not empty.");
        }
        else if (isEmpty == false && numberOfCredits > 2) {
            System.out.println("The class is more than 2 credits and is not empty.");
        } else if (isEmpty == true && (numberOfCredits == 1 || numberOfCredits == 3)){
            System.out.println("The class is one or three credits and the class roster is empty");
        }

        System.out.println("-------------------------------");
        System.out.println("Switch:");

        System.out.println("Enter an integer: ");

        int x = scanner.nextInt();

        switch (x){
            case 1:
                System.out.println("You selected 1.");
                break;
            case 2:
            case 3:
                System.out.println("You selected 2 or 3");
                break;
            case 4:
                System.out.println("You selected 4.");
                break;
            default:
                System.out.println("Select again please");
        }


    }

}
