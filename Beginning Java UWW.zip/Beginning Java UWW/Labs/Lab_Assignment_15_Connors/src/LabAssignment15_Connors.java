import java.io.File;
import java.util.Scanner;

public class LabAssignment15_Connors {

    public static void main(final String[] args) throws Exception {

        System.out.println("The five randomly selected names are: ");

        final File namefile = new File("Names100.txt");
        final Scanner finput = new Scanner(namefile);
        final boolean[] SelectFive = new boolean[100];

        while (finput.hasNext()) {

            final String inputLine = finput.nextLine();

            for (int i = 0; i < inputLine.length(); i++) {

                if (SelectFive[i] == true)
                    System.out.println(namefile);

            }

        }


    }

}
