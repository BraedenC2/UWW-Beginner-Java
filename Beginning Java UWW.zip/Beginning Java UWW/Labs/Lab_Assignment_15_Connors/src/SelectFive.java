public class SelectFive {

    boolean[] arrFive = new boolean[100];

    SelectFive(final boolean[] arrFive) {

        this.arrFive = arrFive;

        for (int i = 0; i < arrFive.length; i++)
            arrFive[i] = false;

        final int a = (int) (Math.random() * 99);
        final int b = (int) (Math.random() * 99);
        final int c = (int) (Math.random() * 99);
        final int d = (int) (Math.random() * 99);
        final int e = (int) (Math.random() * 99);

        for (int i = 0; i < arrFive.length; i++) {

            if (a == i)
                arrFive[i] = true;
            else if (b == i)
                arrFive[i] = true;
            else if (c == i)
                arrFive[i] = true;
            else if (d == i)
                arrFive[i] = true;
            else if (e == i)
                arrFive[i] = true;
            else
                System.out.println();

        }

    }

}
