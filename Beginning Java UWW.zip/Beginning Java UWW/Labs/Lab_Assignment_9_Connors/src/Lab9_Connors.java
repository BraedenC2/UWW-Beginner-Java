public class Lab9_Connors {

    public static void main(String[] args){

quarterToDollars(10);




    }

    public static void printDottedLine(){

        for (int i = 0; i < 5; i++){

            System.out.print(".");

        }
    }

    public static void printGrade(char a){

        System.out.println("Grade: " + a);

    }

    public static void quarterToDollars(int numQ){


        double Doll;
        Doll = (double) numQ/4;
        System.out.println(Doll);

    }

    public static int max(int x, int y, int z){

        int largest = 0;

            if (x > y && x > z){
                largest = x;
            } else if (y > z && y > x){
                largest = y;
            } else if (z > y && z > x){
                largest = z;
            }

            return largest;

    }

}
