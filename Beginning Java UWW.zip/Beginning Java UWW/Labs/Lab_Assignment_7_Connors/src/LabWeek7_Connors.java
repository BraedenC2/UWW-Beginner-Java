import java.util.Scanner;

public class LabWeek7_Connors {

    public static void main(String[] args) {

        int x = 50;

        while (x > 0){
            System.out.println(x + " Seconds to go.");
            x--;
        }

        int count = 0, total = 0;
        
        while (count < 100) {
            count++;
            total += count;      //adding count to total
            System.out.print("The sum of the numbers from 1 to 100 is: ");
            System.out.println(total);
        }


        Scanner scanner = new Scanner(System.in);
        int number;
        do {
            System.out.println("Enter an integer between 1 and 4 inclusive: ");
            number = scanner.nextInt();

        } while (!(number <= 4) || !(number >= 1));

        System.out.println("Your input value is: " + number);

        Scanner sc = new Scanner(System.in);    //Do not forget to import java.util.Scanner;
        int x1, x2;
        char again;
        do {
            System.out.print("Enter two numbers, separated by spaces: ");
            x1 = sc.nextInt();
            x2 = sc.nextInt();
            System.out.println("Their sum is " + (x1 + x2));
            System.out.println("Do you want to do this again? (Y or N) ");
            again = sc.next().charAt(0);
        } while (again == 'y' || again == 'Y');

    }
}
