import java.util.Scanner;


public class AnMain {

    static int input1;
    static double input2;
    static int input3;
    static double[] day;

    public static void main(String[] args){
        System.out.println("Sup, temp time");
        Start();
    }

    public static void Start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("How many days worth of temperature data would you like to enter?:");
        input1 = scanner.nextInt();
        for (int i = 0; input1 <= 0; i++) {
            System.out.println("Number must be greater than 0. Try again.");
            System.out.println("How many days worth of temperature data would you like to enter?:");
            input1 = scanner.nextInt();
        }

        double[] day = new double[input1];
        System.out.println("enter the temperature reading for each day:");

        for (int i = 0; input1 > i; i++) {
            input2 = scanner.nextDouble();
            if ((input2 > 200) || (input2 < -200)) {
                System.out.println("temperature has to be greater than -200 and less than 200");
                i--;
            } else {
                day[i] = input2;
            }
        }

        System.out.println("Your commands are:");
        System.out.println("[1] Print out all of the temperature readings");
        System.out.println("[2] Print out the highest temperature");
        System.out.println("[3] Print out the lowest temperature");
        System.out.println("[4] Print out the average temperature");
        System.out.println("[5] Exit the program :(");
        System.out.println("Please enter your command: ");
        input3 = scanner.nextInt();
        double max = day[0];
        double min = day[0];
        double sum = 0;
        for (int i = 0; i < 1; i++) {
            if (input3 == 1) {
                System.out.println("You have chosen " + input3 + ".");
                //Print out all the temperature readings
                for (int j = 0; j < input1; j++) {
                    System.out.println(day[j]);
                }
            } else if (input3 == 2) {
                //Print out the highest temperature
                for (int j = 0; j < day.length; j++){
                    if (day[i] > max) {
                        max = day[i];
                    }
                }
                System.out.println("Highest temperature was:" + max + "");
            } else if (input3 == 3) {
                //Print out the lowest temperature
                for (int j = 0; j < day.length; j++){
                    if (day[i] < min) {
                        min = day[i];
                    }
                }
                System.out.println("Lowest temperature was:" + min + "");
            } else if (input3 == 4) {
                //Print out the average temperature
                for (int j = 0; j < day.length; j++){
                    sum += day[i];
                }
                double average = sum / day.length;

                System.out.println("Average of array : " + average);
            } else if (input3 == 5){
                System.out.println("GOODBYE");
            }
            else {
                System.out.println("Please, enter a command number!");
                input3 = scanner.nextInt();
                i--;
            }
        }
    }
}

