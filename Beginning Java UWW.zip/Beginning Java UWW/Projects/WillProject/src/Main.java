import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] widgetLinks = {900, 656, 474, 357, 304, 49, 97, 53, 129, 154, 297, 172, 182, 181, 632, 684, 742,
                            1046, 1177, 1025, 726, 857, 564, 998, 1353, 811, 1259, 972, 492, 478, 569};

        int widgetsmLink = widgetLinks[0];
        int dayOfMonthsmall = 0;
        int dayOfMonthlarge = 0;
        int widgetlrLink = widgetLinks[0];

        for (int i = 0; i < widgetLinks.length; i++) {
            if (widgetLinks[i] < widgetsmLink) {
                widgetsmLink = widgetLinks[i];
                dayOfMonthsmall = i+1;
            }}
        for (int i = 0; i < widgetLinks.length; i++) {
            if (widgetLinks[i] > widgetlrLink) {
                widgetlrLink = widgetLinks[i];
                dayOfMonthlarge = i+1;
            }
        }

        System.out.println("The worst day of the month was Oct. " + dayOfMonthsmall + " which only sold " + widgetsmLink +  " widget(s)");
        System.out.println("The best day of the month was Oct. " + dayOfMonthlarge + " which sold " + widgetlrLink + " widgets(s)");

        double profit = 15.50;
        double total = 0;

        for (int i = 0; i < widgetLinks.length; i++){
            total += widgetLinks[i] * profit;
        }

        System.out.println("We made a total monthly profit of " + (int) total);

        int median = 0;
        int j = widgetLinks.length;
        Arrays.sort(widgetLinks);
        if (j % 2 == 1) {
            median = widgetLinks[(j + 1) / 2 - 1];
        } else {
            median = (widgetLinks[j / 2 - 1] + widgetLinks[j / 2]) / 2;
        }

        System.out.println("The median number of widgets sold this month is " + median);

    }
}