import java.util.Scanner;
import javax.swing.*;
public class hello_universe {
    public static void main(String[] args){

                // The double dashed lines are for short comments.
                /* this is for longer comments. Keep in mind that comments are notes and cane not be shown when runned. */

                // Below is how you print words, or variables
                System.out.println("Start:");
                System.out.println("Example");
                // I will show how to make and print variables later

                //In order to make a variable, you have to use either: int , double , String , or boolean
                // int 's are used to hold only numbers. They cannot hold decimals or fractions. ONLY WHOLE NUMBERS
                System.out.println(" " + "int Example:");
                int example1 = 45;
                //or you can do:
                int example2;
                example2 = 34;
                System.out.println(example1);
                System.out.println(example2);
                System.out.println("End of int Examples");

                //Next is doubles
                // doubles are mainly used for decimals, unlike int which doesnt use decimals at all
                //doubles are also used for much highier numbers
                System.out.println(" ");
                System.out.println("Double examples");
                double example3 = 9.99;
                double example4 = 59325768;
                double example5;
                example5 = 10.99;
                System.out.println(example3);
                System.out.println(example4);
                System.out.println(example5);

                //Next are booleans
                // booleans answer yes or no questions
                // for booleans you would use true or false at the end of a =.
                System.out.println(" ");
                System.out.println("boolean example");
                boolean myNameIsBraeden = true;
                boolean myNameIsJeff = false;
                boolean myNameIsBob;
                myNameIsBob = false;
                System.out.println(myNameIsBraeden);
                System.out.println(myNameIsJeff);
                System.out.println(myNameIsBob);

                //Next are chars
                //chars hold any type of character, letter, space, or punctuation mark
                //they must be in single quotes ''
                System.out.println(" ");
                System.out.println("char example");
                char one = '1';
                char abcFirstLetter = 'A';
                char punctuation = '!';
                char ex;
                ex = '2';
                System.out.println(one);
                System.out.println(abcFirstLetter);
                System.out.println(punctuation);
                System.out.println(ex);

                //Next are Strings
                //Strings are used to hold sentences (anything, words, numbers, etc) within a variable
                System.out.println(" ");
                System.out.println("String Example");
                String example6 = "This is a example of what Strings can do";
                String example7 = "1001";
                System.out.println(example7);
                System.out.println(example6);

                //Next is Manipulation Variables
                //Manipulation of Variable lets us divide, subtract, multiply, or add within our variables
                System.out.println(" ");
                System.out.println("Maniplulation of Variables (add, subtract, multiply, and divide) ");
                int example8 = 3 + 4;
                System.out.println(example8);
                int example9 = 3 - 4;
                System.out.println(example9);

                //More indepth is here:
                double exp1 = 20.99;
                double exp2 = 99.90;
                double expF = exp1 + exp2;
                System.out.println(expF);
                int esp1 = 4;
                int esp2 = 5;
                int espF = esp1 - esp2;
                System.out.println(espF);

                //Multiplication and Division:
                //for Multiplication and Division we use * to multiply and / to divide
                double time1 = 30 * 30.1;
                double divide1 = 20 / 4;
                System.out.println(time1);
                System.out.println(divide1);
                //ints when multiplying or dividing get rid of the decimal to make it a whole number
                int time2 = 10 / 2;
                int divide2 = 10/4;
                System.out.println(time2);
                System.out.println(divide2);
                //now to divide and multiply variables:
                double times1 = 55.5;
                double times2 = 2;
                double timesF = times1 * times2;
                System.out.println(timesF);
                double divd1 = 5;
                double divd2 = 3;
                double divdF = divd1 / divd2;
                System.out.println(divdF);

                //next will be about Modulo
                // % gives us the remainder after 2 numbers are divided
                System.out.println(" ");
                System.out.println("Modulo example");
                int modulo1 = 10 % 3;
                System.out.println(modulo1);

                //Next is: Greater than and less than
                // the symbols are ((<) less than) and ((>) greater than)
                System.out.println(" ");
                System.out.println("Greater than and Less than examples");
                double gLE1 = 2000.200;
                double gLE2 = 3000.30;
                System.out.println(gLE1 > gLE2);
                //This will print false since gLE1 is less than gLE2
                System.out.println(gLE1 < gLE2);
                //This will print true since gLE2 is greater than gLE1

                //next is Equals and not Equals
                //the symbols used here are ==
                //This tells us if two variables are equal or not. instead of using greater than and less than
                System.out.println(" ");
                System.out.println("Equals and not Equals example");
                double eE1 = 200;
                double eE2 = 20 * 3;
                System.out.println(eE1 == eE2);
                //this will print false since they are not equal

                //To check to see if they are not equal we would use !=
                System.out.println(eE1 != eE2);

                //next is Greater/Less than or Equal to
                //the symbols used here are >= and <=
                System.out.println(" ");
                System.out.println(" Greater/Less than or Equal to example");
                double gLEE1 = 620;
                double gLEE2 = 15.50 * 40;
                System.out.println(gLEE1 >= gLEE2);
                //This will print true since they are equal

                //Next are .equals()
                //.equals() tells us if a variable name is equal to another variable name (numbers or letters/words)
                System.out.println(" ");
                System.out.println(".equals() example");
                String person1 = "Paul";
                String person2 = "John";
                String person3 = "Pual";
                System.out.println(person1.equals(person2));
                //will print false
                System.out.println(person1.equals(person3));
                //will print true

                //Next is String Concatenation
                //using + in a print command will combined two strings together
                System.out.println(" ");
                System.out.println("String Concatenation example");
                String myName0 = "Braeden";
                System.out.println("My name is:" + myName0);
                //This also works with numbers
                //you can contain multiple "+" in this operation

                //Next are classes: Syntax
                //A class is a set of instructions that tells hoe a instance can behave
                /*A example is at the start of a program:
                 * public class everythingILearned {
                 * public static void main(String[] args) {
                 * }
                 * }
                 */

                //Next are classes: Constructors
                //We use:  new  <VERY IMPORTANT] to indicate we're creating a instance
                /* A example:
                 * LOOK IN Bob.java CLASS OR Store.java CLASS!!!
                 */

                //From This Point on everything has gone Pro:

                //Next are Classes: Assigning Values To Instance Fields
                //This is used to change the product name
                //This code product name is now lemonade
                //to print the product name locate line 205 which shows renaming, and line 206 which shows printing the name.
                //Notice printing the name of the product type is different than usual
	/*public class Store {
  // instance fields
  String productType;

  // constructor method
  public Store(String product) {
    productType = product;
  }

  // main method
  public static void main(String[] args) {
    Store lemonadeStand = new Store("lemonade");
    System.out.println(lemonadeStand.productType);
  }
}*/

                //Classes: Multiple Fields
                //We use this to increase as many instance fields we want
                //    *LOOK IN multipleFields CLASS

                //REVIEW ALL CODE

	/*

	 public class Dog {
  String breed;
  boolean hasOwner;
  int age;

  public Dog(String dogBreed, boolean dogOwned, int dogYears) {
    System.out.println("Constructor invoked!");
    breed = dogBreed;
    hasOwner = dogOwned;
    age = dogYears;
  }

  public static void main(String[] args) {
    System.out.println("Main method started");
    Dog fido = new Dog("poodle", false, 4);
    Dog nunzio = new Dog("shiba inu", true, 12);
    boolean isFidoOlder = fido.age > nunzio.age;
    int totalDogYears = nunzio.age + fido.age;
    System.out.println("Two dogs created: a " + fido.breed + " and a " + nunzio.breed);
    System.out.println("The statement that fido is an older dog is: " + isFidoOlder);
    System.out.println("The total age of the dogs is: " + totalDogYears);
    System.out.println("Main method finished");
  }
}

	 */



                //Introduction to Methods


                //This is a loonnnnnng version without methods

	/*

	 public class SavingsAccount {

  int balance;

  public SavingsAccount(int initialBalance){
    balance = initialBalance;
  }

  public static void main(String[] args){
    SavingsAccount savings = new SavingsAccount(2000);

    //Check balance:
    System.out.println("Hello!");
    System.out.println("Your balance is "+savings.balance);

    //Withdrawing:
    int afterWithdraw = savings.balance - 300;
    savings.balance = afterWithdraw;
    System.out.println("You just withdrew "+300);

    //Check balance:
    System.out.println("Hello!");
    System.out.println("Your balance is "+savings.balance);

    //Deposit:
    int afterDeposit = savings.balance + 600;
    savings.balance = afterDeposit;
    System.out.println("You just deposited "+600);

    //Check balance:
    System.out.println("Hello!");
    System.out.println("Your balance is "+savings.balance);

    //Deposit:
    int afterDeposit2 = savings.balance + 600;
    savings.balance = afterDeposit2;
    System.out.println("You just deposited "+600);

    //Check balance:
    System.out.println("Hello!");
    System.out.println("Your balance is "+savings.balance);

  }
}


	 */



                //Defining Methods
                //public means that other classes can access this method. We will learn more about that later in the course.
                //The void keyword means that there is no specific output from the method. We will see methods that are not void later in this lesson, but for now all of our methods will be void.
                //startEngine() is the name of the method.
                //Example of Defining Methods: public void advertise(){}
                //advertise is the method in this line (It can be changed)


                //Calling Methods
                //Calling Methods sends our other methods we have written and announces them in the output
                //To call a Method, use for example:
	/*

	 public class Store {
  // instance fields
  String productType;

  // constructor method
  public Store(String product) {
    productType = product;
  }

  // advertise method
  public void advertise() {
		System.out.println("Selling " + productType + "!");
    System.out.println("Come spend some money!");
  }

  // main method
  public static void main(String[] args) {
    Store lemonadeStand = new Store("Lemonade");
    lemonadeStand.advertise();                            < This is how you would call it
    lemonadeStand.advertise();                            <
    lemonadeStand.advertise();                            <
  }
}

	 */


                //Scope
                //The definition of Scope is everything inside the method of the curly braces {}
                //You cannot use System.out.println when calling/printing methods



                //Adding Parameters
                // Check: paramentersExample.java Class for Example



                //Returns
                //The type of the variables that are output are declared in the method signature

                // if
                // this code allows something to happen if the code matches with the required need
	/* if (condition) {

  	// Do something

		} */

                // else
                //This code only runs if the required code needed for if doesnt meet the requirements.

                //else if
                // this code gives off a... "if A isnt equal to 20, then try if A is equal to 15. if not, go to the last resort "else".

                //this is how we write a code with these:

	/* public double calculateShipping() {
    if (shipping.equals("Regular")) {
      return 0;
    } else if (shipping.equals("Express")) {
      // Add your code here
      if (couponCode.equals("ship50")){
        return .85;
        } else {
          return 1.75;
        } */

                // switch
                // this will switch a number or name of a variable if it is equal to something
                // to use it, you do; switch (*what you wanna change*) {}

                //case
                // this is HOW you change something and what you change that something to
                // to use this you do; case "*what u wanna change it to*":
                /* change something to something * */

                // break
                // this will end a case. always use this after your case and command
                // you just do: break;

                //default
                // this is what it will say/do after whatever you changed it to doesnt work
                // you just do: default: *and then seperate line, a comamnd*.

                //Ex of breaks and cases:

	/* switch (value) {

  case possibleMatchingValue:
    // do something
    break;
  case anotherPossibleMatching:
    // do another thing
    break;
  default:
    // do this if nothing else matched
} */

                // SUM UP:

	/* if-then:
code block runs if condition is true
if-then-else:
one block runs if conditions is true
another block runs if condition is false
if-then-else chained:
same as if-then but an arbitrary number of conditions
switch:
switch block runs if condition value matches case value
*/

                //&&
                // this is a AND operator. works with multiple ifs and elses. used for making multiple conditions true to run a code.

                // ||
                // this is a OR operator. also works with multiple ifs and elses. used for "run a code block if at least one of two conditions are true"

                // !
                // this is a NOT operator. works w. ifs and elses multiple amounts. "we can produce the opposite value, where true becomes false and false becomes true"

                //HOW TO SOLVE FOR TRUE/FALSE
                //TRY SOLVING:
	/*   boolean ex1 = !(a == 7 && (b >= a || a != a));
    System.out.println(ex1);

    boolean ex2 = a == b || !(b > 3);
    System.out.println(ex2);

    boolean ex3 = !(b <= a && b != a + b);
     System.out.println(ex3);  */

                // && - if there are 2 true, it will equal true. if there are 2 opposites (true, false), it will equal false.
                // || = if there are 2 opposites, it will equal true
                // ! = makes a true, false. and a false, true. (makes them opposite)

                // Java Arrays are to store a list of something.
                // they look like this: public String[] getTopics(){}       . String[] can be replaced with int[], boolean[], ect.

                //Loops
                //A loop is a programming tool that allows developers to repeat the same block of code until some condition is met.

                //While
                //  a while loop will only run if the condition is true. However, a while loop will continue running the code over and over until the condition evaluates to false
                // while loops look like this:
                // While () {}
                //Here is a more detailed of what whiles are used for:
	/* int pushupsToDo = 10;

	while (pushupsToDo > 0) {

	  doPushup();
	  pushupsToDo--;

	} */

                // do
                // this is used with while(s), and will run first, and then run the while commmand.
                //example: do {}
	/*
	 int a = 0;
	do {
	System.out.println("hi")
	} while (a == 1);

	*/ //this will run the output, and then 'while', and stop running the output. since a is equal to 0, not 1, it will end at while.
                //if 'a' in 'while' equaled 0, then it would run forever.

                // For
                // this is how you write the code: for () {}
                // here is an simple code: for (int i = 0; i < 5; i++) {

                // code that will run
//}
                // here is a fill in for that code:

	/*
	 *
	 *  for (int cupsOfCoffee = 1; cupsOfCoffee <= 100; cupsOfCoffee++) {

      System.out.println("Fry drinks cup of coffee #" + cupsOfCoffee);
	 */

                // Scanners
                // These are used for inputs :)
                // look in the ScannerTut class for more info and example.

                // For arrays, they are lists.
                // check out arrayEX class for more info and example.

                // long
                // these are used like ints. they increase the size you can make a number. cant use decimals
                // They are used like this: long a = 1109527495827L;
                // the bottom L after the numbers can be uppercase or lowercase. "L" or "l"

                // float
                // these are used like ints, but they cannot increase the size of the max number. It uses decimals
                // They are used like this: float a = 23982.32F;
                // the bottom F after the numbers can be uppercase or lowercase "F" or "f".

                // Exponents
                // to make a exponent in java, use this code: Math.pow(a,b)
                // 'a' is the number, and b is the exponent. this code will give you decimals
                // if you dont want decimals, use: (int) Math.pow(a,b)

                // 2D Array
                // Example:
	/*
	int[][] lotteryCard = { { 20, 15, 7 },         <   This is the code used to make the 2D array
							 { 8, 7, 19 },           <
							 { 7, 13, 41 }           <
		};                                              <

		int[][] lotteryCard2 = new int[3][3];
		lotteryCard2[0][0] = 20;
		lotteryCard2[0][1] = 15;
		lotteryCard2[0][2] = 7;
		lotteryCard2[1][0] = 8;
		lotteryCard2[1][1] = 7;
		lotteryCard2[1][2] = 19;
		lotteryCard2[2][0] = 7;
		lotteryCard2[2][1] = 13;
		lotteryCard2[2][1] = 41;

		// [row][column]
		System.out.println(lotteryCard[0][0]

		System.out.println("---------");

		for (int i = 0; i <= 2; i++) {             			This prints the diagonal numbers in the array
			System.out.println(lotteryCard[i][i]);
		}

		System.out.println("---------");

		for (int i = 0; i <= 2; i++) {                        This prints all of the numbers in the array
			for (int j = 0; j <= 2; j++) {
				System.out.println(lotteryCard[i][j]);
			}
		}
	*/

                // Making Methods
                //To make a method, just use: static void methodname() {}
                //To call this, type: methodname(); in the main method.

                //Casting
                // to change a double(or another number operator) to a int(or another number operator), you would do this for an example:
                /*
                 * double a = 400;
                 *
                 * int b = (int) a;
                 */

                // Permenant Variable
                // To make a int or number that never changes, you type:
                /*
                 * static final int EXAMPLE = 100;
                 *
                 * public static void main(String[] args) {}
                 */
                //This 'EXAMPLE' can NEVER change. not even EXAMPLE++; will be able to change this variable.
                // This can also work with String s.

                // Conditional Operator
                // this will give us a true and false scenario. with both numbers and strings
                // Example:
                /*
                 * int a = (7 > 3) ? 7 : 3;
                 *
                 * System.out.println(a);
                 */
                // If the result of 7 > 3 is true (what the '?' stands for), then it will print '7'. if it is false, then it will print 3.
                // to seperate the true and false outcomes, you use ':'. on the left side is what 'a' will equal to if the outcome is true.
                // in the right side is what 'a' will equal to if the outcome is false.
                //For an String example;
                /*
                 * String a = "hello";
                 * -and we want to make 'a' a number with making "hello" equal to something, we do this next line;
                 * double aAsNumber = a.equals("hello") ? 2 : 3.2;
                 *-                               ^  If this is "goodbye" it will print out as our false number(3.2).
                 *-                               ^ Since this is was 'a' is equal to, then it will print out 2.
                 */

                // I.D.A
                //These are I.D.A s
                /*
                 * String example1 = "Example"; <Initialization
                 * String example2; <Declaration
                 * example2 = "Example"; <Assignment
                 *
                 */

                // GUI
                // Look at LoginGUI.java if this doesnt make sense
                // To start creating a GUI, first type in: JPanel EXAMPLE = new JPanel();	Don't forget to import
                // Now type: JFrame EXAMPLE = new JFrame();		IMPORT
                // To set the size of this frame, type: EXAMPLE.setSize(x, y);
                // To make sure this doesnt close by itself, type: EXAMPLE.SetDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                // Now to add this frame, type: EXAMPLE.add(panel);
                // Now we have to make the panel to have the frame show. Type: EXAMPLE.setLayout(null);		<make sure EXAMPLE is named the variable for the panel before
                // Now lastly to make it show, type: EXAMPLE.setVisible(true); Make sure this is below everything
                // ---
                // To print words in the GUI, type: JLabel EXAMPLE = new JLabel();   	< In the () you can add "" and type in words to have it print
                // Now to make the bounds of this word/Label, type: EXAMPLE.setBounds(x, y, w, h);
                // Now to have it show in the panel, type: panel.add(EXAMPLE);		panel is the variable what whatever we named the JPanel, and EXAMPLE is our Variable we just added uptop
                // To clear a GUI, type these two codes: EXAMPLE.setText(s); AND EXAMPLE.repaint();		< IN THIS ORDER

                // Break
                // To use a break, type: break;
                // Breaks get you out of loops. for example:
        /*
           while(true) {
            System.out.println("HI");
            break;
        }
         */
                // This loop would go on forever, but since break; is there, it only prints "HI" once.

                // Method
                // To make code more simplestic, for example, you can do this:
        /*

public static void main(String[] args) {

        int a = 3;
        int b = 6;
        System.out.println(a * b);

        int c = 7;
        int d = 9;
        System.out.println(c * d);

        int e = 23;
        int f = 2;
        System.out.println(e * f);

    }
         */
                // and to make that more simple, make a method like this:
        /*

        multiply(5, 10);
        multiply(2, 29);
        multiply(12, 43);

     public static void multiply(int a, int b) {
        System.out.println(a * b);
    }
         */
                // A even more advance would be this:
        /*
        		welcome();
		multiply(5, 100);
		multiply(2, 3);
		multiply(6, 8);
		divide(20, 5);
		divide(100, 10);
		divide(66, 11);

	}

	public static void welcome() {
		System.out.println("Welcome to our calculator!");
	}

	public static void multiply(int a, int b) {
		System.out.println(a * b);
	}

	public static void divide(int a, int b) {
		System.out.println(a / b);
	}

}
         */

                // String Methods
                // making uppercase, lowercase, etc:
        /*
                String name = "Braeden";

        System.out.println("name: " + name);
        System.out.println("Uppercase: " + name.toUpperCase());
        System.out.println("Lowercase: " + name.toLowerCase());
        System.out.println("First character: " + name.charAt(0));
        System.out.println("Length: " + name.length());
        System.out.println("Substring: " + name.substring(5));
         */

                // Current Time
        /*
                Date currentDate = new Date();
        System.out.println(currentDate);
         */
                // This is how you get the current hour, min, and sec:
        /*
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss");
        System.out.println(timeFormat.format(currentDate));
         */
                // This is how you get the current mount, day, year:
        /*
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        System.out.println(dateFormat.format(currentDate));
         */
                // For more date stuff: https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html

                // Reading Text File
                // This lets you print and locate a text file in java
        /*
         public static void main(String[] args) throws FileNotFoundException {

        File file =  new File("INSERT FILE LOCATION IN FILES");
        Scanner scan = new Scanner(file);

        while (scan.hasNext()) {
            System.out.println(scan.nextLine());
        }
    }
         */

                // Switch case in more depth
                // Int example:
        /*
                int day = 3;

        switch (day) {
            case 1:                              < if day == 1, then this code will run
                System.out.println("Sunday");
                    break;                       < This breaks the code. needed for ending what you want case to exceed
            case 2:                              < if day == 2, then this code will run
                System.out.println("Monday");
                    break;
            default:                             < default is the "else" in this kind of code. If day doesnt make 1 or 2, it will run this.
                System.out.println("Not a Valid day number");
        }
         */
                // String example:
        /*
      String dog = "lexi";

        switch (dog) {
            case ("lexi"):
                System.out.println("Shes cute");
                break;
            case ("Baylee"):
                System.out.println("Shes mean");
                break;
            default:
                System.out.println("What dog name?");
        }
         */

                //  Exceptions
                // These are error codes in your program. it will show in the console as the error, or a piece
                // - of your code that cant/doesn't work.

                // ArrayList
                // Like Arrays, but a little different.
                // They can add, remove, clear, a little bit more flexible, contains.
                // Arrays are for smaller things
                // Here is an example for a ArrayList:
        /*
        ArrayList fruitList = new ArrayList();    < This creates our ArrayList
        fruitList.add("Mango");                   < This is how you add String Arrays in our list
        fruitList.add("Apple");
        fruitList.add("Banana");

        fruitList.remove("Apple");                < This is how you remove from print
        fruitList.clear();                        < This is how you clear all from print
        System.out.println(fruitList.contains("Banana"));       < This is how you check to see if bananas are in the list (will print true)
        System.out.println(fruitList.contains("Watermelon"));           < we do not have watermelons, so this will print false

        System.out.println(fruitList);                             < This is how you print the ArrayList
         */

                // Null pointer
                // Nulls are like a placeholder for a String or an array, ect.
                // It is a keyword like Int, but is nothing.
                // String a = null;        < This will print null since its a placeholder
                // String a = "bob";         < This will print bob since this is actually something

                // Try Catch
                // If a code cannot work, and will show a exception, you can use catch(){} and your program will run something else if it doesnt work
                // To try to see if your code doesnt work, type try{INSERT CODES HERE}.
                // for example:
        /*
            try {
                 int[] a = {4, 5, 1};
            System.out.println(a[3]);
            } catch (Exception e) {
             System.out.println("An Exception happened");
            }
         */
                // This code will prince out "An Exception happened" because our array will be an error.
                // if we didnt have a try catch method, then our program would error and show Exception thread error.
                // Another Example:
        /*
                Scanner scan = new Scanner(System.in);
        System.out.println("What is your favorite number");
        try {
            int n = scan.nextInt();
            System.out.println(n);
        } catch (Exception e) {
            System.out.println("Sorry, please enter a number");
            main(null);
        }
         */

                // Hashmap
                // These are another way in storing a bunch of Ints
                // Example:
        /*
                HashMap<String, Integer> happy = new HashMap<String, Integer>();
        happy.put("a", 10);
        happy.put("b", 43);
        happy.put("c", 49);
        System.out.println(happy);
        System.out.println(happy.get("b"));
         */
                // Here is a String example:
        /*
                HashMap<String, String> fun = new HashMap<String, String>();         < we replace the <> with both strings
            fun.put("BobbyJoe", "FluffyPonies");
            fun.put("Helloboy", "Password123");
            fun.put("goofygoober", "masterplaster");

            fun.remove("Helloboy");                   <this has removed "Helloboy" completely from the hashmap. It WILL NOT show

            System.out.println(fun.containsValue("Password123"));           <Value is on the right side of these. This will print false tho since we removed its key
            System.out.println(fun.containsKey("Helloboy"));           < Key is ont he left side, this will print false since we removed it before
        System.out.println(fun.containsValue("FluffyPonies"));       < This will print true since we havent removed it, and its in our fun.put()
        System.out.println(fun.size());                             < This will print 2, since we have two fun.put() 's. We removed 1 before
        System.out.println(fun.replace("goofygoober","betterplaster"));     < This will removed the value of goofygoober (masterplaster) to "netterplaster", and the output will be "masterplaster" since thats what we're removing
        System.out.println(fun);                                  < This will print everything (but what we removed)
        System.out.println(fun.values());                       < This will print everything on the right side
        System.out.println(fun.keySet());                     < This will print everything on the left side
         */

                // Hashset
                // These do NOT allow duplicates, and can also store strings and ints.
        /*
        HashSet<String> h = new HashSet<String>();                  < This is how you create a Hashset string
        h.add("Lion");                  < This is how you create stuff inside the HashSet
        h.add("Gorilla");
        h.add("Monkey");

        h.remove("Lion");                   < This is how you remove a string inside
        h.clear();                  < This is how you clear them all
        System.out.println(h.size());                   < This is how you print the amount of strings
        System.out.println(h.contains("Gorilla"));                  < This is a boolean for seeing if Gorrilla is in the hashmap

        System.out.println(h);                  < This prints them all
         */
                // Here is another example:
        /* HashSet<Integer> hashbrowns = new HashSet<Integer>();                    < This is how you create a HashSet with Ints
        hashbrowns.add(33);                 < This is how you add ints in the Hashset
        hashbrowns.add(24);
        hashbrowns.add(5);

        Iterator<Integer> it = hashbrowns.iterator();                   < You use this to repeat the code from bottom up. (5, 24, 33).
        while (it.hasNext()) {                  <
            System.out.println(it.next());                  <
        }

        Object[] h = hashbrowns.toArray();                  < This is how you turn a HashSet into an Array
        System.out.println(h[0]);                   < This is how you print as an array
        System.out.println(hashbrowns.hashCode());                  < This adds all of the ints up to a sum
         */

                // Java Access Modifiers
                // Default is similar to Public. Works around all packages and classes:
                // Example: int a = 2;  would work in different classes and different packages
                // Public is just the same as the default example, but you use:
                // public int a = 2;
                // Private will only function for that one class that it is in. Cannot be called in other classes or packages
                // private int a = 2;
                // lastly, Protected lets it only to be called in a class of the same packages. other packages outside will not function.
                // protected int a = 3;
                // To call these from different classes and packages, use CLASSNAME a = new CLASSNAME();

                // Math Library
                // To use math codes, type Math.EXAMPLE to show all available outcomes.

                //  Stacks
                // This is how you stack variables/words/ints/etc into a tower like form
                // Example:
        /*
        Stack<String> game = new Stack<String>();      < This is how you create a string Stack

        game.add("Call Of Duty");                     < this is on the bottom of the tower
        game.add("Guitar Hero");                       < Middle
        game.add("Super Monkey Ball");                 < Top

        System.out.println(game.pop());                < This is how you print out the top game.
        System.out.println(game.pop());                < When you have more than one, it'll print out the next on top
        System.out.println(game.pop());

        System.out.println(game.peek());               < This will do the same as "pop" but will not take it out of the tower... try it to understand


        System.out.println(game);                     < This is how you print them all out in order.
         */

                // Queue
                // Queues in Java help you know who/what is next in line.
                // Example:
        /*
        Queue<String> bbq = new LinkedList<String>();     < How you create a string queue

        bbq.add("Jackson");                            < How you add names to the queue
        bbq.add("Jameson");
        bbq.add("Susan");

        bbq.poll();                                       < How you take names out of the queue (will print Jackson first. not like Stacks)
        bbq.poll();                                       < The more you have, itll print the next (Jameson, then Susan)
        bbq.poll();

        System.out.println(bbq.peek());                   < This is how to look to see whos next in line. it will not take out from the list.

        System.out.println(bbq);                        < This is how you print them all
         */

                // For Each loop
                // These help you print out all arrays in a list
                // Example:
        /*

        String[] foods = {"Burger", "Fries", "Hotdogs"};          < First create a array that we can print

        for (String food : foods){                                < Since we have a string for our array, we add the string in our for each
            System.out.println(food);                             < Print it out, and it'll show all 3 of these foods
        }
         */
                // Basically, you just place the variable in place of x in: for (B : x){}. and in place of B, put the Int, String, ---
                // --- Double, ect and a new variable. (can be anything).

                // Finally
                // This is a clean up for the try {} and catch () {} codes
                // Example:
        /*
           Scanner scan = new Scanner(System.in);        < This is just the scanner we're using for this example
        try {
            System.out.println(scan.nextInt());          < This will ask for a int, but we'll give it a word so a error occurs
        } catch (Exception e) {                          < This will try to catch a error
            System.out.println("WRONG");                 < This will print WRONG if we don't type a int
        } finally {                                      < This is our clean up crew. it will run after catch
            scan.close();                                < This will close the scanner to prevent any errors
        }
         */

                // Method Parameters
                // Example:
        /*
            public static void main(String[] args) {
        saySomething("Braeden");
        saySomething("God");
        saySomething("bobby");                             < These 3 names will print since they all equal 's'.

    } public static void saySomething(String s) {          < this will print out all of our names
        System.out.println(s);                             < s is the variable
    }
         */
                // Another Example another way:
        /*
    public static void main(String[] args) {

        printInfo("Braeden", 18);
        printInfo("Bob", 34);                              < These will print the name and ages variable. all of them in order.
        printInfo("Brett", 17);

    } public static void printInfo(String name, int age) {      < This will be looking for a string and a age.
        System.out.println(name + " is " + age + " years old");       < Prints it
    }
         */

                // Null Keyword
                // Null refers to nothing. Nulls only work with Strings and Objects. NOT INTS OR ANYTHING SIMILAR!

                // String Comparison
                // Example:
        /*
                String a = "DOG f Id ";                   < This is what 'a' is equal to
        if (a.toLowerCase().equals("dog f id ")) {          < the lowerc case will make a lower case, and then compare it to our string
            System.out.println("true");                   < And this will print true, since a does equal our string lowercased
        } else {
            System.out.println("false");
        }
         */

                // Method Chain
                // This is used when wanting to convert a string into many different outcomes in a method
                // Example:
        /*
                String a = "Doug diamond";
        System.out.println(a.toLowerCase().charAt(0));  < This will print just our 'd'. because 'D' in "Doug" is now lowercased, and char is picking it out from 0.

         */

                // Object Arrays
                // Turn your objects into arrays
                // Example:
        /*
        class Monkey {                          < We make a class
    String type = "Spider monkey";              < Make a string called type variable

    public static void sayOohAhhAhh() {             < Make a method
        System.out.println("Ohh Ahh Ahh");          < What our method will say
    }
}
public class Break {                                < Original starting class
    public static void main(String[] args) {

        Monkey m1 = new Monkey();                   < Make 3 calling objects
        Monkey m2 = new Monkey();
        Monkey m3 = new Monkey();

        Monkey[] monkeys = {m1, m2 ,m3};            < This will make those 3 objects into a array called "monkeys".

        for(Monkey m : monkeys) {                   < This will turn that array into m, and print our method from the start 3 times.
            m.sayOohAhhAhh();
        }
         */

                // INTERMEDIATE CLASS NOW!!!!!

                // Recursive Methods
                // These are used to call and repeat methods
                // Example:
        /*
            public static void main(String[] args) {
        sayHi(5);                                           < We call our method, and it starts at 5, and counts down
    }
    public static void sayHi(int n) {                       < n is equal to 5
        if( n == 0) {                                       < once n is equal to 0, we will print "Done!"
            System.out.println("Done!");
        } else {
            System.out.println("hi");                       < It will print this 5 times
            n--;                                            < decrease the value of 'n'
            sayHi(n);                                       < calls our method again so it can repeat.
        }
         */

                // Enums
                // We use enum 's as labels. They do not change. a example of an real life is levels.
                // Example of a Enum outside of class:
        /*
        enum Level {            < this is how we create and name our enum outside of a class
    LOW, MEDIUM, HIGH;          < our labels in a enum
}

public class Break {            < Start of class

    public static void main(String[] args) {

        Level l = Level.LOW;                < this is renaming our Level to a variable of l

        switch(l) {                         < this will check to see if l is equal to LOW
            case LOW:
                System.out.println("Low level");        < will print this
                break;
            case MEDIUM:                                < will now print this, or HIGH since l = LOW
                System.out.println("Medium level");
                break;
            case HIGH:
                System.out.println("High level");
                break;
        }
         */
                // Another example inside the class:
        /*
public class Break {

    enum Flavor {                                   < create and name our enum
        CHOCOLATE, VANILLA, STRAWBERRY;             < It is recommended we use caps for our label to avoid confusion
    }

    public static void main(String[] args) {

        Flavor flav = Flavor.VANILLA;               < turn flavor.(any label) into flav. will apply to all labels

        if(flav == Flavor.VANILLA) {
            System.out.println("It's Vanilla");
        } else if(flav == Flavor.CHOCOLATE) {
            System.out.println("It's Chocolate");
        } else if(flav == Flavor.STRAWBERRY) {
            System.out.println("It's Strawberry");
        }

         */

                // This
                // 'this' is used to make variable equal to the variable to avoid confusing with the computer
                // Example:
        /*
        public class Break {

    int a;                                  < create our int and variable
    int b;

    public void setData(int a, int b) {             < we CANNOT use static when using 'this'
        this.a = a;                                 < if we didnt have 'this.a' in our code here, and just had "a = a;" it wouldnt work. because the compuyer would get confused of which one was the variable
        this.b = b;                                 < this.b specifys that b is the variable, and what it is equaling to is the number
    }

    public static void main(String[] args) {

        Break t = new Break();                      < we have to make a new object and name it our class

        t.setData(4, 3);                            < call our object and method

        System.out.println(t.a);                    < print out what t.a (this.a) is equal to
        System.out.println(t.b);
         */

                // Encryption and Decryption




            }
        }



    }
}
