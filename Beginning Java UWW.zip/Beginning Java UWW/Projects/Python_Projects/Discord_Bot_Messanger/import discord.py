import discord

client = discord.Client(intents=discord.Intents.all())

@client.event
async def on_ready():
    # get the user you want to send the message to
    user = discord.utils.get(client.get_all_members(), name='XXX', discriminator= 'XXX')

    # send the message
    if user is None:
        print('Error: user not found')
    else:
        # send the message
        await user.send('Btw this is only a 1 way conversation, so send them to the server.')
    
    #use this to invite bot to a server: https://discord.com/oauth2/authorize?client_id=1051610894171389992&scope=bot

client.run('MTA1MTYxMDg5NDE3MTM4OTk5Mg.GKxUKH.eTe-7lM9LCWJbI_qX46meSMJi6QkDD3RAOYvcE')